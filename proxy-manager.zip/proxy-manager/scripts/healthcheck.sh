#!/usr/bin/env bash
# Quick health check script for VPS services

echo "=== Mobile Proxy Manager Service Health ==="

echo -n "1. Node.js Backend: "
if curl -s http://127.0.0.1:3001/api/health | grep -q "HEALTHY"; then
  echo "[OK] Running"
else
  echo "[FAIL] Not responding"
fi

echo -n "2. Nginx Web Server: "
if systemctl is-active nginx >/dev/null 2>&1; then
  echo "[OK] Active"
else
  echo "[WARNING] Inactive or Not Found"
fi

echo -n "3. Database SQLite: "
if [ -f "/home/ubuntu/proxy-manager/database/proxy-manager.db" ]; then
  echo "[OK] Found"
else
  echo "[FAIL] Missing"
fi

echo -n "4. Backend Systemd Service: "
if systemctl is-active proxy-manager-backend.service >/dev/null 2>&1; then
  echo "[OK] Active"
else
  echo "[INFO] Inactive (Start via proxy-manager start)"
fi
