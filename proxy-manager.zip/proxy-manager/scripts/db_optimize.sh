#!/usr/bin/env bash
# Database maintenance and WAL checkpoint script

DB_FILE="/home/ubuntu/proxy-manager/database/proxy-manager.db"

if [ -f "$DB_FILE" ]; then
  echo "Optimizing database: $DB_FILE ..."
  node -e "
    const db = require('/home/ubuntu/proxy-manager/backend/src/utils/db').getDb();
    db.pragma('wal_checkpoint(TRUNCATE)');
    db.exec('VACUUM');
    console.log('WAL checkpointed and VACUUM completed.');
  "
else
  echo "Database file not found: $DB_FILE"
fi
