#!/usr/bin/env bash
# Universal Production Installer for Mobile Proxy Manager on VPS
# Supports: Ubuntu (20.04/22.04/24.04), Debian (10/11/12), CentOS/RHEL/AlmaLinux/RockyLinux (8/9), Fedora, Alpine, Arch
# Architectures: x86_64, aarch64 (ARM64), armv7l

set -e

echo "============================================================"
echo "    Mobile Proxy Manager - Universal Production Installer"
echo "============================================================"

if [ "$EUID" -ne 0 ]; then
  echo "[-] Error: Please run as root (or with sudo)."
  exit 1
fi

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Parse optional arguments for fully non-interactive automation
while [[ $# -gt 0 ]]; do
  case $1 in
    --user) ADMIN_USER="$2"; shift 2 ;;
    --password) ADMIN_PASS="$2"; shift 2 ;;
    --port) SERVER_PORT="$2"; shift 2 ;;
    -y|--yes) NON_INTERACTIVE=true; shift ;;
    *) shift ;;
  esac
done

echo "[*] Detecting Operating System and Architecture..."
OS_NAME="Unknown"
DISTRO="unknown"
ARCH="$(uname -m)"

if [ -f /etc/os-release ]; then
  . /etc/os-release
  DISTRO="$ID"
  DISTRO_LIKE="${ID_LIKE:-$ID}"
  OS_NAME="$PRETTY_NAME"
fi

echo "    Distro: $OS_NAME ($DISTRO)"
echo "    Architecture: $ARCH"

echo "[*] Installing core dependencies based on package manager..."

if command -v apt-get >/dev/null 2>&1; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get install -y curl wget git sqlite3 nginx openssl build-essential ufw ca-certificates
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y epel-release || true
  dnf install -y curl wget git sqlite nginx openssl gcc gcc-c++ make ca-certificates
elif command -v yum >/dev/null 2>&1; then
  yum install -y epel-release || true
  yum install -y curl wget git sqlite nginx openssl gcc gcc-c++ make ca-certificates
elif command -v pacman >/dev/null 2>&1; then
  pacman -Sy --noconfirm curl wget git sqlite nginx openssl base-devel ca-certificates
elif command -v apk >/dev/null 2>&1; then
  apk update
  apk add curl wget git sqlite nginx openssl build-base ca-certificates bash nodejs npm
fi

# Ensure Node.js 18+ is installed
echo "[*] Verifying Node.js version..."
NEED_NODE=false
if ! command -v node >/dev/null 2>&1; then
  NEED_NODE=true
else
  NODE_VER=$(node -v | cut -d'.' -f1 | tr -d 'v')
  if [ "$NODE_VER" -lt 18 ]; then
    NEED_NODE=true
  fi
fi

if [ "$NEED_NODE" = true ]; then
  echo "[*] Installing Node.js LTS (20.x)..."
  if command -v apt-get >/dev/null 2>&1; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
  elif command -v dnf >/dev/null 2>&1 || command -v yum >/dev/null 2>&1; then
    curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
    if command -v dnf >/dev/null 2>&1; then
      dnf install -y nodejs
    else
      yum install -y nodejs
    fi
  elif command -v pacman >/dev/null 2>&1; then
    pacman -S --noconfirm nodejs npm
  fi
fi

echo "    Node.js: $(node -v 2>/dev/null || echo 'N/A')"
echo "    NPM:     v$(npm -v 2>/dev/null || echo 'N/A')"

echo "[*] Setting up directories and permissions..."
mkdir -p "$DIR/logs" "$DIR/database" "$DIR/backups"
chmod -R 755 "$DIR"

echo "[*] Configuring environment..."
if [ ! -f "$DIR/.env" ]; then
  cp "$DIR/.env.example" "$DIR/.env"
fi

# Ensure JWT_SECRET is cryptographically secure and unique per installation
CURRENT_JWT=$(grep -E "^JWT_SECRET=" "$DIR/.env" 2>/dev/null | cut -d'=' -f2)
if [ -z "$CURRENT_JWT" ] || [ "$CURRENT_JWT" = "super_secret_jwt_change_me_in_production_32chars_minimum" ]; then
  NEW_JWT=$(openssl rand -hex 32 2>/dev/null || node -e 'console.log(require("crypto").randomBytes(32).toString("hex"))')
  sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$NEW_JWT|" "$DIR/.env"
fi

sed -i "s|DB_PATH=.*|DB_PATH=$DIR/database/proxy-manager.db|" "$DIR/.env"
sed -i "s|LOG_DIR=.*|LOG_DIR=$DIR/logs|" "$DIR/.env"

echo "[*] Installing backend dependencies..."
cd "$DIR/backend"
npm install --production

echo "[*] Running database migrations..."
node src/utils/migrate.js

# Setup Admin Account (Interactive or Automated)
if [ -z "$ADMIN_USER" ]; then
  if [ "$NON_INTERACTIVE" = true ]; then
    ADMIN_USER="admin"
    ADMIN_PASS="$(openssl rand -base64 12)"
    echo "    Generated Admin Username: $ADMIN_USER"
    echo "    Generated Admin Password: $ADMIN_PASS"
  else
    echo ""
    echo "=== Create Admin Account ==="
    read -p "Enter Admin Username [admin]: " ADMIN_USER
    ADMIN_USER=${ADMIN_USER:-admin}
    read -s -p "Enter Admin Password [min 8 chars, press enter for random]: " ADMIN_PASS
    echo ""
    if [ -z "$ADMIN_PASS" ]; then
      ADMIN_PASS="$(openssl rand -base64 12)"
      echo "    Generated Admin Password: $ADMIN_PASS"
    fi
  fi
else
  ADMIN_PASS="${ADMIN_PASS:-$(openssl rand -base64 12)}"
fi

node -e "
const { createAdminUser } = require('./src/services/auth');
createAdminUser('$ADMIN_USER', '$ADMIN_PASS').then(() => process.exit(0)).catch(() => process.exit(0));
"

echo "[*] Configuring Nginx..."
NGINX_CONF_DEST=""
if [ -d /etc/nginx/sites-available ]; then
  cp "$DIR/nginx/proxy-manager.conf" /etc/nginx/sites-available/proxy-manager.conf
  mkdir -p /etc/nginx/sites-enabled
  ln -sf /etc/nginx/sites-available/proxy-manager.conf /etc/nginx/sites-enabled/proxy-manager.conf
  rm -f /etc/nginx/sites-enabled/default
else
  mkdir -p /etc/nginx/conf.d
  cp "$DIR/nginx/proxy-manager.conf" /etc/nginx/conf.d/proxy-manager.conf
fi

echo "[*] Configuring SSH Server for Reverse Tunnel Gateway Ports..."
if [ -d /etc/ssh/sshd_config.d ]; then
  cat << 'EOF' > /etc/ssh/sshd_config.d/proxy-manager-gateway.conf
GatewayPorts yes
ClientAliveInterval 30
ClientAliveCountMax 3
TCPKeepAlive yes
EOF
elif [ -f /etc/ssh/sshd_config ]; then
  if ! grep -q "GatewayPorts yes" /etc/ssh/sshd_config; then
    echo "GatewayPorts yes" >> /etc/ssh/sshd_config
  fi
fi

# Reload SSH service safely
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || service ssh reload 2>/dev/null || service sshd reload 2>/dev/null || true

echo "[*] Publishing Termux agent package for seamless auto-install..."
mkdir -p "$DIR/frontend/dist"
cp "$DIR/tunnel/start_tunnel.sh" "$DIR/agent/" 2>/dev/null || true
cp "$DIR/tunnel/stop_tunnel.sh" "$DIR/agent/" 2>/dev/null || true
tar -czf "$DIR/frontend/dist/agent.tar.gz" -C "$DIR/agent" .
cp "$DIR/install-agent.sh" "$DIR/frontend/dist/install-agent.sh"
chmod 644 "$DIR/frontend/dist/agent.tar.gz" "$DIR/frontend/dist/install-agent.sh" 2>/dev/null || true

# Configure SELinux if active (RHEL/CentOS/Rocky/Alma/Fedora)
if command -v getenforce >/dev/null 2>&1; then
  if [ "$(getenforce)" != "Disabled" ]; then
    setsebool -P httpd_can_network_connect 1 2>/dev/null || true
  fi
fi

nginx -t 2>/dev/null && (systemctl restart nginx || rc-service nginx restart || service nginx restart || true)

echo "[*] Setting up Service (Systemd / OpenRC)..."
SERVICE_USER="${SUDO_USER:-$(logname 2>/dev/null || echo root)}"
if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  SERVICE_USER="root"
fi

if command -v systemctl >/dev/null 2>&1; then
  sed -i "s|User=.*|User=$SERVICE_USER|" "$DIR/systemd/proxy-manager-backend.service"
  sed -i "s|WorkingDirectory=.*|WorkingDirectory=$DIR/backend|" "$DIR/systemd/proxy-manager-backend.service"
  sed -i "s|ExecStart=.*|ExecStart=$(which node) src/index.js|" "$DIR/systemd/proxy-manager-backend.service"
  sed -i "s|EnvironmentFile=.*|EnvironmentFile=$DIR/.env|" "$DIR/systemd/proxy-manager-backend.service"

  cp "$DIR/systemd/proxy-manager-backend.service" /etc/systemd/system/
  systemctl daemon-reload
  systemctl enable proxy-manager-backend.service
  systemctl restart proxy-manager-backend.service
elif command -v rc-service >/dev/null 2>&1; then
  cat << EOF > /etc/init.d/proxy-manager-backend
#!/sbin/openrc-run
name="proxy-manager-backend"
description="Mobile Proxy Manager Backend Service"
directory="$DIR/backend"
command="$(which node)"
command_args="src/index.js"
command_user="$SERVICE_USER"
command_background="true"
pidfile="/run/proxy-manager-backend.pid"

depend() {
  need net
  after firewall
}
EOF
  chmod +x /etc/init.d/proxy-manager-backend
  rc-update add proxy-manager-backend default 2>/dev/null || true
  rc-service proxy-manager-backend restart 2>/dev/null || true
fi

# Setup CLI symlink
ln -sf "$DIR/cli/proxy-manager" /usr/local/bin/proxy-manager
chmod +x /usr/local/bin/proxy-manager 2>/dev/null || true

echo "[*] Configuring Firewall..."
if command -v ufw >/dev/null 2>&1 && ufw status | grep -qw "active"; then
  ufw allow 80/tcp || true
  ufw allow 443/tcp || true
  ufw allow 10000:10100/tcp || true
elif command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active firewalld >/dev/null 2>&1; then
  firewall-cmd --permanent --add-service=http || true
  firewall-cmd --permanent --add-service=https || true
  firewall-cmd --permanent --add-port=10000-10100/tcp || true
  firewall-cmd --reload || true
fi

PUBLIC_IP=$(curl -s --max-time 5 https://api.ipify.org || hostname -I | awk '{print $1}')

echo ""
echo "===================================="
echo "    INSTALLATION COMPLETE"
echo "===================================="
echo "Dashboard:      http://$PUBLIC_IP/"
echo "Admin Username: $ADMIN_USER"
if [ -n "$ADMIN_PASS" ]; then
  echo "Admin Password: $ADMIN_PASS"
fi
echo "Backend Status: ONLINE"
echo "Nginx:          ONLINE"
echo "CLI Command:    proxy-manager status"
echo ""
echo "Termux Auto-Install Command (Jalankan di Android):"
echo "  Mode Data Seluler: curl -fsSL http://$PUBLIC_IP/install-agent.sh | bash -s -- http://$PUBLIC_IP <TOKEN> \"HP-Seluler\" cellular"
echo "  Mode WiFi:         curl -fsSL http://$PUBLIC_IP/install-agent.sh | bash -s -- http://$PUBLIC_IP <TOKEN> \"HP-WiFi\" wifi"
echo "  Mode Interaktif:   curl -fsSL http://$PUBLIC_IP/install-agent.sh | bash"
echo "===================================="
