'use strict';

/**
 * Proxy Manager Core Service Connector
 */
const { getDb } = require('../backend/src/utils/db');
const { rotateProxy } = require('../backend/src/services/rotationManager');
const { fullHealthCheck } = require('../backend/src/services/healthChecker');

class ProxyCore {
  static getList() {
    return getDb().prepare('SELECT * FROM proxies ORDER BY created_at DESC').all();
  }

  static getById(id) {
    return getDb().prepare('SELECT * FROM proxies WHERE id=?').get(id);
  }

  static async test(id) {
    const proxy = this.getById(id);
    if (!proxy) throw new Error('Proxy not found');
    return fullHealthCheck(proxy);
  }

  static async rotate(id) {
    return rotateProxy(id, 'MANUAL');
  }
}

module.exports = ProxyCore;
