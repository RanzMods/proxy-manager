# Panduan Troubleshooting

## 1. Status Agent "OFFLINE"
- Pastikan Termux tidak dimatikan oleh sistem Android (*Battery Optimization -> Unrestricted*).
- Jalankan `termux-wake-lock` di Termux.
- Cek log agent: `cat ~/proxy-agent/agent.log`.

## 2. Rotasi IP Mengembalikan "IP_UNCHANGED"
- BTS/Operator seluler sering memberikan kembali alamat IP yang sama dari subnet yang sama jika durasi jeda mode pesawat terlalu singkat.
- Naikkan durasi jeda mode pesawat di `agent/network_controller.py`.

## 3. Proxy Tidak Bisa Konek dari Luar
- Pastikan port proxy (range 10000-10100) sudah dibuka di firewall VPS: `sudo ufw allow 10000:10100/tcp`.
- Jika menggunakan Mode B (Carrier NAT), pastikan reverse tunnel aktif.
