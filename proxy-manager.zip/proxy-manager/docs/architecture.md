# Panduan Arsitektur Mobile Proxy Manager

## 1. Konsep Dasar
Mobile Proxy Manager memanfaatkan koneksi seluler asli (SIM Card 4G/5G) pada perangkat Android yang menjalankan Termux sebagai sumber egress traffic (public IP).

## 2. Diagram Alur
```
[Client] ──> [VPS Proxy Endpoint :10001] ──> [Reverse Tunnel] ──> [Termux SOCKS5] ──> [SIM Card / LTE] ──> [Target Website]
```

## 3. Komponen
- **Control Plane (VPS)**: Menyediakan REST API, Web Dashboard, otentikasi JWT, health checker otomatis, dan agregasi status.
- **Data Plane (Termux)**: Menjalankan agent Python, server SOCKS5 bawaan, pelacakan byte traffic real-time, dan controller rotasi IP.
