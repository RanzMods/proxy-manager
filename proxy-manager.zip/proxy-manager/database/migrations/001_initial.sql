-- Migration 001: Initial schema
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- Users (admin dashboard)
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin',
  last_login TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Agents (Termux devices)
CREATE TABLE IF NOT EXISTS agents (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  device_model TEXT,
  android_version TEXT,
  termux_version TEXT,
  architecture TEXT,
  status TEXT NOT NULL DEFAULT 'UNKNOWN',
  public_ip TEXT,
  previous_ip TEXT,
  ip_verified INTEGER NOT NULL DEFAULT 0,
  ip_provider TEXT,
  last_ip_check TEXT,
  network_interface TEXT,
  carrier TEXT,
  network_type TEXT,
  uptime_seconds INTEGER DEFAULT 0,
  last_heartbeat TEXT,
  heartbeat_latency_ms INTEGER,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  reconnect_supported INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Agent tokens
CREATE TABLE IF NOT EXISTS agent_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  token_prefix TEXT NOT NULL,
  revoked INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT
);

-- Pairing tokens (one-time use)
CREATE TABLE IF NOT EXISTS pairing_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL UNIQUE,
  used INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL
);

-- Networks
CREATE TABLE IF NOT EXISTS networks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  interface_name TEXT,
  carrier TEXT,
  network_type TEXT,
  public_ip TEXT,
  ip_verified INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Proxies
CREATE TABLE IF NOT EXISTS proxies (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL DEFAULT 'SOCKS5',
  listen_host TEXT NOT NULL DEFAULT '0.0.0.0',
  listen_port INTEGER NOT NULL UNIQUE,
  agent_id TEXT REFERENCES agents(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'UNKNOWN',
  current_public_ip TEXT,
  previous_ip TEXT,
  ip_verified INTEGER NOT NULL DEFAULT 0,
  ip_provider TEXT,
  rotation_mode TEXT NOT NULL DEFAULT 'DISABLED',
  rotation_interval_seconds INTEGER DEFAULT 3600,
  health_check_interval_seconds INTEGER NOT NULL DEFAULT 60,
  last_health_check TEXT,
  last_rotation TEXT,
  uptime_seconds INTEGER DEFAULT 0,
  latency_ms INTEGER,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Proxy credentials
CREATE TABLE IF NOT EXISTS proxy_credentials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  proxy_id TEXT NOT NULL UNIQUE REFERENCES proxies(id) ON DELETE CASCADE,
  username TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- IP history
CREATE TABLE IF NOT EXISTS ip_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT REFERENCES agents(id) ON DELETE SET NULL,
  proxy_id TEXT REFERENCES proxies(id) ON DELETE SET NULL,
  old_ip TEXT,
  new_ip TEXT,
  method TEXT NOT NULL DEFAULT 'MANUAL',
  result TEXT NOT NULL DEFAULT 'UNKNOWN',
  latency_ms INTEGER,
  verification_status TEXT NOT NULL DEFAULT 'UNVERIFIED',
  ip_provider TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Health checks
CREATE TABLE IF NOT EXISTS health_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  proxy_id TEXT NOT NULL REFERENCES proxies(id) ON DELETE CASCADE,
  agent_id TEXT REFERENCES agents(id) ON DELETE SET NULL,
  tcp_ok INTEGER DEFAULT 0,
  socks5_ok INTEGER DEFAULT 0,
  auth_ok INTEGER DEFAULT 0,
  outbound_ok INTEGER DEFAULT 0,
  dns_ok INTEGER DEFAULT 0,
  https_ok INTEGER DEFAULT 0,
  egress_ip TEXT,
  egress_ip_verified INTEGER DEFAULT 0,
  latency_ms INTEGER,
  final_status TEXT NOT NULL DEFAULT 'UNKNOWN',
  error_message TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Heartbeat events
CREATE TABLE IF NOT EXISTS heartbeat_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  public_ip TEXT,
  network_type TEXT,
  proxy_status TEXT,
  uptime_seconds INTEGER,
  latency_ms INTEGER,
  received_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Rotation events
CREATE TABLE IF NOT EXISTS rotation_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  proxy_id TEXT REFERENCES proxies(id) ON DELETE SET NULL,
  agent_id TEXT REFERENCES agents(id) ON DELETE SET NULL,
  triggered_by TEXT NOT NULL DEFAULT 'MANUAL',
  old_ip TEXT,
  new_ip TEXT,
  result TEXT NOT NULL DEFAULT 'UNKNOWN',
  duration_ms INTEGER,
  error_message TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Proxy events
CREATE TABLE IF NOT EXISTS proxy_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  proxy_id TEXT REFERENCES proxies(id) ON DELETE SET NULL,
  agent_id TEXT REFERENCES agents(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL,
  old_status TEXT,
  new_status TEXT,
  message TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Logs
CREATE TABLE IF NOT EXISTS logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  level TEXT NOT NULL DEFAULT 'INFO',
  component TEXT NOT NULL,
  agent_id TEXT,
  proxy_id TEXT,
  ip TEXT,
  message TEXT NOT NULL,
  metadata TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Settings
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Audit logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_username TEXT,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  old_value TEXT,
  new_value TEXT,
  result TEXT NOT NULL DEFAULT 'SUCCESS',
  ip_address TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  level TEXT NOT NULL DEFAULT 'INFO',
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  agent_id TEXT,
  proxy_id TEXT,
  read INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Tunnels
CREATE TABLE IF NOT EXISTS tunnels (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  proxy_id TEXT REFERENCES proxies(id) ON DELETE SET NULL,
  type TEXT NOT NULL DEFAULT 'SSH_REVERSE',
  vps_port INTEGER NOT NULL,
  remote_port INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'DISCONNECTED',
  pid INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(status);
CREATE INDEX IF NOT EXISTS idx_agents_public_ip ON agents(public_ip);
CREATE INDEX IF NOT EXISTS idx_agent_tokens_agent_id ON agent_tokens(agent_id);
CREATE INDEX IF NOT EXISTS idx_proxies_agent_id ON proxies(agent_id);
CREATE INDEX IF NOT EXISTS idx_proxies_status ON proxies(status);
CREATE INDEX IF NOT EXISTS idx_ip_history_agent_id ON ip_history(agent_id);
CREATE INDEX IF NOT EXISTS idx_ip_history_proxy_id ON ip_history(proxy_id);
CREATE INDEX IF NOT EXISTS idx_ip_history_created_at ON ip_history(created_at);
CREATE INDEX IF NOT EXISTS idx_health_checks_proxy_id ON health_checks(proxy_id);
CREATE INDEX IF NOT EXISTS idx_health_checks_created_at ON health_checks(created_at);
CREATE INDEX IF NOT EXISTS idx_heartbeat_events_agent_id ON heartbeat_events(agent_id);
CREATE INDEX IF NOT EXISTS idx_heartbeat_events_received_at ON heartbeat_events(received_at);
CREATE INDEX IF NOT EXISTS idx_rotation_events_proxy_id ON rotation_events(proxy_id);
CREATE INDEX IF NOT EXISTS idx_rotation_events_created_at ON rotation_events(created_at);
CREATE INDEX IF NOT EXISTS idx_logs_level ON logs(level);
CREATE INDEX IF NOT EXISTS idx_logs_component ON logs(component);
CREATE INDEX IF NOT EXISTS idx_logs_agent_id ON logs(agent_id);
CREATE INDEX IF NOT EXISTS idx_logs_proxy_id ON logs(proxy_id);
CREATE INDEX IF NOT EXISTS idx_logs_created_at ON logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read);
CREATE INDEX IF NOT EXISTS idx_tunnels_agent_id ON tunnels(agent_id);

-- Default settings
INSERT OR IGNORE INTO settings(key, value) VALUES
  ('dashboard_name', 'Mobile Proxy Manager'),
  ('timezone', 'UTC'),
  ('heartbeat_interval_seconds', '5'),
  ('heartbeat_timeout_seconds', '30'),
  ('heartbeat_max_failures', '3'),
  ('health_check_interval_seconds', '60'),
  ('default_proxy_port', '10001'),
  ('default_rotation_interval_seconds', '3600'),
  ('log_retention_days', '30'),
  ('ip_providers', '["https://api.ipify.org?format=json","https://api4.my-ip.io/ip.json","https://ipapi.co/json/"]'),
  ('ip_conflict_threshold', '2'),
  ('auto_restart_on_failure', 'true'),
  ('telegram_enabled', 'false'),
  ('telegram_bot_token', ''),
  ('telegram_chat_id', ''),
  ('discord_enabled', 'false'),
  ('discord_webhook_url', ''),
  ('email_enabled', 'false'),
  ('stale_data_threshold_seconds', '120');
