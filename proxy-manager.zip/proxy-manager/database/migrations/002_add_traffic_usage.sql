-- Migration 002: Add real-time traffic usage tracking
ALTER TABLE proxies ADD COLUMN bytes_in INTEGER DEFAULT 0;
ALTER TABLE proxies ADD COLUMN bytes_out INTEGER DEFAULT 0;
ALTER TABLE proxies ADD COLUMN total_bytes INTEGER DEFAULT 0;

ALTER TABLE agents ADD COLUMN bytes_in INTEGER DEFAULT 0;
ALTER TABLE agents ADD COLUMN bytes_out INTEGER DEFAULT 0;
ALTER TABLE agents ADD COLUMN total_bytes INTEGER DEFAULT 0;

CREATE TABLE IF NOT EXISTS traffic_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT REFERENCES agents(id) ON DELETE SET NULL,
  proxy_id TEXT REFERENCES proxies(id) ON DELETE SET NULL,
  bytes_in INTEGER NOT NULL DEFAULT 0,
  bytes_out INTEGER NOT NULL DEFAULT 0,
  total_bytes INTEGER NOT NULL DEFAULT 0,
  recorded_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_traffic_history_proxy_id ON traffic_history(proxy_id);
CREATE INDEX IF NOT EXISTS idx_traffic_history_agent_id ON traffic_history(agent_id);
CREATE INDEX IF NOT EXISTS idx_traffic_history_recorded_at ON traffic_history(recorded_at);
