'use strict';

/**
 * Standalone health check runner for scheduled jobs or CLI usage
 */
const { fullHealthCheck, tcpConnect, socks5Handshake } = require('../backend/src/services/healthChecker');
const { getDb } = require('../backend/src/utils/db');

async function checkAllProxies() {
  const db = getDb();
  const proxies = db.prepare('SELECT * FROM proxies').all();
  console.log(`Running health checks on ${proxies.length} proxy/proxies...`);

  for (const proxy of proxies) {
    const cred = db.prepare('SELECT * FROM proxy_credentials WHERE proxy_id=?').get(proxy.id);
    const result = await fullHealthCheck({ ...proxy, password_plain: cred?.username ? 'dummy' : null });
    console.log(`[${result.final_status}] ${proxy.name} (Port ${proxy.listen_port}) - Egress: ${result.egress_ip || 'N/A'}`);
  }
}

module.exports = { checkAllProxies, tcpConnect, socks5Handshake };

if (require.main === module) {
  checkAllProxies().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
}
