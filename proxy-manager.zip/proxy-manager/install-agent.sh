#!/data/data/com.termux/files/usr/bin/bash
# Termux Agent Auto-Installer for Android
# Fully automated or interactive installation with Wakelock & Termux:Boot support

set -e

echo "============================================================"
echo "    Termux Agent Auto-Installer - Mobile Proxy Manager"
echo "============================================================"

# Check if running in Termux
if [ ! -d "/data/data/com.termux" ]; then
  echo "[-] Error: This script must be run inside Termux on Android."
  exit 1
fi

VPS_URL=""
PAIRING_TOKEN=""
DEVICE_NAME="Termux-Device-$(uname -m)"
NETWORK_CHOICE="cellular"
AUTO_START=true

# Parse arguments for 100% automated / one-liner install
while [[ $# -gt 0 ]]; do
  case $1 in
    --vps) VPS_URL="$2"; shift 2 ;;
    --token) PAIRING_TOKEN="$2"; shift 2 ;;
    --name) DEVICE_NAME="$2"; shift 2 ;;
    --net|--network) NETWORK_CHOICE="$2"; shift 2 ;;
    --no-start) AUTO_START=false; shift ;;
    *)
      if [ -z "$VPS_URL" ]; then
        VPS_URL="$1"
      elif [ -z "$PAIRING_TOKEN" ]; then
        PAIRING_TOKEN="$1"
      elif [ -z "$DEVICE_NAME" ]; then
        DEVICE_NAME="$1"
      elif [ -z "$INPUT_NET_POS" ]; then
        INPUT_NET_POS="$1"
        NETWORK_CHOICE="$1"
      fi
      shift
      ;;
  esac
done

echo "[*] Updating Termux packages (non-interactive)..."
export DEBIAN_FRONTEND=noninteractive
pkg update -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" 2>/dev/null || apt update -y 2>/dev/null || true

echo "[*] Installing dependencies (Python, Git, OpenSSH, Autossh, Termux-API, Curl, Tar)..."
pkg install -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" \
  python git openssh autossh termux-api curl tar 2>/dev/null || apt install -y python git openssh autossh termux-api curl tar 2>/dev/null || true

# Termux Wakelock to prevent Android background killer
echo "[*] Requesting Termux Wake-Lock..."
termux-wake-lock 2>/dev/null || true

# Setup Agent Directory
INSTALL_DIR="$HOME/proxy-agent"
mkdir -p "$INSTALL_DIR"

# If parameters were not provided via CLI, prompt interactively
if [ -z "$VPS_URL" ] || [ -z "$PAIRING_TOKEN" ]; then
  echo ""
  echo "=== Agent Pairing Configuration ==="
  if [ -z "$VPS_URL" ]; then
    read -p "Enter VPS URL (e.g. http://103.xxx.xxx.xxx or https://domain.com): " VPS_URL
  fi
  if [ -z "$PAIRING_TOKEN" ]; then
    read -p "Enter Pairing Token (from VPS Dashboard -> Agents): " PAIRING_TOKEN
  fi
  if [ -z "$DEVICE_NAME" ]; then
    read -p "Enter Device Name [$DEVICE_NAME]: " INPUT_NAME
    DEVICE_NAME=${INPUT_NAME:-$DEVICE_NAME}
  fi

  echo ""
  echo "Pilih Sumber Koneksi Internet untuk Proxy:"
  echo "  1) Data Internet Seluler (SIM Card / 4G / 5G) [Rekomendasi]"
  echo "  2) WiFi (Koneksi Jaringan WiFi Rumah / Kantor / Hotspot)"
  read -p "Pilihan Anda [1/2, default 1]: " INPUT_NET
  if [ "$INPUT_NET" = "2" ] || [ "$INPUT_NET" = "wifi" ] || [ "$INPUT_NET" = "WiFi" ]; then
    NETWORK_CHOICE="wifi"
  else
    NETWORK_CHOICE="cellular"
  fi
fi

# Clean VPS_URL trailing slash
VPS_URL="${VPS_URL%/}"

echo "[*] Setting up Agent source files..."
AGENT_SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/agent" 2>/dev/null && pwd || echo "")"
if [ -n "$AGENT_SRC_DIR" ] && [ -f "$AGENT_SRC_DIR/agent.py" ]; then
  cp -r "$AGENT_SRC_DIR"/* "$INSTALL_DIR/"
elif [ -f "agent.py" ]; then
  cp *.py "$INSTALL_DIR/"
else
  echo "[*] Fetching agent package directly from VPS ($VPS_URL/agent.tar.gz)..."
  curl -fsSL "$VPS_URL/agent.tar.gz" -o "$INSTALL_DIR/agent.tar.gz"
  tar -xzf "$INSTALL_DIR/agent.tar.gz" -C "$INSTALL_DIR"
  rm -f "$INSTALL_DIR/agent.tar.gz"
fi

chmod +x "$INSTALL_DIR"/*.py 2>/dev/null || true

echo "[*] Pairing agent with VPS: $VPS_URL (Mode: ${NETWORK_CHOICE^^}) ..."
cd "$INSTALL_DIR"
python3 agent.py pair "$VPS_URL" "$PAIRING_TOKEN" "$DEVICE_NAME" "$NETWORK_CHOICE"

# Create Service Scripts in $HOME
echo "[*] Generating background service scripts..."

cat << 'EOF' > "$HOME/start-agent.sh"
#!/data/data/com.termux/files/usr/bin/bash
cd $HOME/proxy-agent
termux-wake-lock 2>/dev/null || true
pkill -f "python3 agent.py" 2>/dev/null || true
nohup python3 agent.py > agent.log 2>&1 &
PID=$!
echo "Agent started in background (PID: $PID)."
EOF

cat << 'EOF' > "$HOME/stop-agent.sh"
#!/data/data/com.termux/files/usr/bin/bash
pkill -f "python3 agent.py" 2>/dev/null || true
pkill -f "socks5_server.py" 2>/dev/null || true
pkill -f "autossh" 2>/dev/null || true
pkill -f "ssh.*-R.*127.0.0.1" 2>/dev/null || true
termux-wake-unlock 2>/dev/null || true
echo "Agent and tunnel stopped."
EOF

cat << 'EOF' > "$HOME/start-tunnel.sh"
#!/data/data/com.termux/files/usr/bin/bash
cd $HOME/proxy-agent
if [ -f "start_tunnel.sh" ]; then
  bash start_tunnel.sh "$@"
else
  echo "Error: start_tunnel.sh not found."
fi
EOF

cat << 'EOF' > "$HOME/stop-tunnel.sh"
#!/data/data/com.termux/files/usr/bin/bash
pkill -f "autossh" 2>/dev/null || true
pkill -f "ssh.*-R.*127.0.0.1" 2>/dev/null || true
echo "Tunnel stopped."
EOF

cat << 'EOF' > "$HOME/restart-agent.sh"
#!/data/data/com.termux/files/usr/bin/bash
"$HOME/stop-agent.sh"
sleep 2
"$HOME/start-agent.sh"
EOF

cat << 'EOF' > "$HOME/status-agent.sh"
#!/data/data/com.termux/files/usr/bin/bash
if pgrep -f "python3 agent.py" > /dev/null; then
  echo "[ONLINE] Termux Agent is RUNNING."
  echo "=== Recent Logs ==="
  tail -n 10 "$HOME/proxy-agent/agent.log" 2>/dev/null || true
else
  echo "[OFFLINE] Termux Agent is STOPPED."
fi
if pgrep -f "ssh.*-R" > /dev/null || pgrep -f "autossh" > /dev/null; then
  echo "[TUNNEL] Reverse Tunnel is ACTIVE."
else
  echo "[TUNNEL] Reverse Tunnel is INACTIVE."
fi
EOF

chmod +x "$HOME"/*-agent.sh "$HOME"/*-tunnel.sh 2>/dev/null || true

# Termux:Boot Auto-Start on Reboot support
BOOT_DIR="$HOME/.termux/boot"
mkdir -p "$BOOT_DIR"
cat << 'EOF' > "$BOOT_DIR/start-proxy-agent.sh"
#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
"$HOME/start-agent.sh"
EOF
chmod +x "$BOOT_DIR/start-proxy-agent.sh"

echo "[*] Termux:Boot hook installed at $BOOT_DIR/start-proxy-agent.sh"

# Auto-start immediately if enabled
if [ "$AUTO_START" = true ]; then
  echo "[*] Auto-starting agent now..."
  "$HOME/start-agent.sh"
fi

echo ""
echo "============================================================"
echo "               TERMUX AGENT READY & RUNNING!"
echo "============================================================"
echo "Commands:"
echo "  Start:   ~/start-agent.sh"
echo "  Stop:    ~/stop-agent.sh"
echo "  Restart: ~/restart-agent.sh"
echo "  Status:  ~/status-agent.sh"
echo "  Logs:    cat ~/proxy-agent/agent.log"
echo "============================================================"
