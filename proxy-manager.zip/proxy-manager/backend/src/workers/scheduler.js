'use strict';

const cron = require('node-cron');
const { getDb } = require('../utils/db');
const { aggregateStatus } = require('../services/statusEngine');
const { autoRotationTick } = require('../services/rotationManager');
const { fullHealthCheck } = require('../services/healthChecker');
const { recordAgentFailure } = require('../services/agentManager');
const { getSetting } = require('../utils/helpers');
const logger = require('../utils/logger');

function initScheduler() {
  cron.schedule('*/5 * * * * *', async () => {
    try {
      const db = getDb();
      const timeoutSec = parseInt(getSetting('heartbeat_timeout_seconds', '30'), 10);
      const staleAgents = db.prepare(`
        SELECT id FROM agents
        WHERE status != 'OFFLINE'
          AND (last_heartbeat IS NULL OR datetime(last_heartbeat, '+' || ? || ' seconds') < datetime('now'))
      `).all(timeoutSec);

      for (const agent of staleAgents) {
        await recordAgentFailure(agent.id);
      }
      aggregateStatus();
    } catch (err) {
      logger.error(`Status aggregator error: ${err.message}`, 'SCHEDULER');
    }
  });

  cron.schedule('* * * * *', async () => {
    try {
      await autoRotationTick();
    } catch (err) {
      logger.error(`Auto rotation error: ${err.message}`, 'SCHEDULER');
    }
  });

  cron.schedule('*/30 * * * * *', async () => {
    try {
      const db = getDb();
      const proxies = db.prepare(`
        SELECT * FROM proxies WHERE status NOT IN ('OFFLINE')
      `).all();

      for (const proxy of proxies) {
        const interval = proxy.health_check_interval_seconds || 60;
        const lastCheck = proxy.last_health_check ? new Date(proxy.last_health_check) : null;
        const elapsed = lastCheck ? (Date.now() - lastCheck.getTime()) / 1000 : Infinity;

        if (elapsed >= interval) {
          fullHealthCheck(proxy).catch(e => {
            logger.warn(`Background HC failed for ${proxy.name}: ${e.message}`, 'HEALTH');
          });
        }
      }
    } catch (err) {
      logger.error(`Health checker scheduler error: ${err.message}`, 'SCHEDULER');
    }
  });

  logger.info('Background scheduler initialized', 'SCHEDULER');
}

module.exports = { initScheduler };
