'use strict';

const path = require('path');
require('dotenv').config({
  path: [
    path.join(__dirname, '../../.env'),
    path.join(__dirname, '../.env'),
    path.join(process.cwd(), '.env')
  ]
});

const express = require('express');
const http = require('http');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const compression = require('compression');

const logger = require('./utils/logger');
const { getDb } = require('./utils/db');
const { apiLimiter } = require('./middleware/rateLimiter');
const { addClient } = require('./services/sseManager');
const { initScheduler } = require('./workers/scheduler');

const authRoutes = require('./routes/auth');
const proxiesRoutes = require('./routes/proxies');
const agentsRoutes = require('./routes/agents');
const ipHistoryRoutes = require('./routes/ipHistory');
const logsRoutes = require('./routes/logs');
const statusRoutes = require('./routes/status');
const settingsRoutes = require('./routes/settings');
const auditLogsRoutes = require('./routes/auditLogs');
const notificationsRoutes = require('./routes/notifications');
const analyticsRoutes = require('./routes/analytics');

const app = express();
const server = http.createServer(app);

app.use(helmet({
  contentSecurityPolicy: false,
}));
app.use(cors({
  origin: process.env.CORS_ORIGIN || true,
  credentials: true,
}));
app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use('/api', apiLimiter);

app.get('/api/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();
  addClient(res);
  res.write(`data: ${JSON.stringify({ type: 'INIT', timestamp: new Date().toISOString() })}\n\n`);
});

app.use('/api/auth', authRoutes);
app.use('/api/proxies', proxiesRoutes);
app.use('/api/agents', agentsRoutes);
app.use('/api/ip-history', ipHistoryRoutes);
app.use('/api/logs', logsRoutes);
app.use('/api/status', statusRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/audit-logs', auditLogsRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/analytics', analyticsRoutes);

app.get('/api/health', (req, res) => {
  res.json({
    status: 'HEALTHY',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

const staticDir = path.join(__dirname, '../../frontend/dist');
app.use(express.static(staticDir));
app.get('*', (req, res) => {
  res.sendFile(path.join(staticDir, 'index.html'));
});

app.use((err, req, res, next) => {
  logger.error(`Unhandled error: ${err.message}`, 'SERVER', { stack: err.stack });
  res.status(500).json({ error: 'Internal Server Error' });
});

const PORT = process.env.PORT || 3001;
const HOST = process.env.HOST || '0.0.0.0';

server.listen(PORT, HOST, () => {
  logger.info(`Backend listening on ${HOST}:${PORT}`, 'SERVER');
  initScheduler();
});

function gracefulShutdown(signal) {
  logger.info(`Received ${signal}. Shutting down gracefully...`, 'SERVER');
  server.close(() => {
    try {
      getDb().close();
    } catch (_) {}
    process.exit(0);
  });
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

process.on('unhandledRejection', (reason, promise) => {
  logger.error(`Unhandled Rejection at: ${promise}, reason: ${reason}`, 'SERVER');
});

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught Exception: ${err.message}`, 'SERVER', { stack: err.stack });
});
