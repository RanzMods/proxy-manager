'use strict';

const { getDb } = require('../utils/db');
const { getSetting } = require('../utils/helpers');
const { updateProxyStatus } = require('./statusEngine');
const { detectProxyEgressIp } = require('./ipDetection');
const { broadcast } = require('./sseManager');
const notificationService = require('./notificationService');
const logger = require('../utils/logger');

const ROTATION_TIMEOUT_MS = 120000;

async function sendCommandToAgent(agentId, command, payload = {}) {
  const db = getDb();
  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(agentId);
  if (!agent || agent.status === 'OFFLINE') {
    return { success: false, error: 'Agent offline or not found' };
  }

  broadcast({ type: 'AGENT_COMMAND', agentId, command, payload, timestamp: new Date().toISOString() });
  return { success: true, queued: true };
}

async function rotateProxy(proxyId, triggeredBy = 'MANUAL') {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(proxyId);
  if (!proxy) return { result: 'PROXY_NOT_FOUND' };

  const agent = proxy.agent_id ? db.prepare('SELECT * FROM agents WHERE id=?').get(proxy.agent_id) : null;
  if (!agent) return { result: 'NO_AGENT' };

  if (agent.status === 'OFFLINE') return { result: 'AGENT_OFFLINE' };

  const oldIp = proxy.current_public_ip;
  const t0 = Date.now();

  logger.info(`Rotation started for proxy ${proxy.name}`, 'ROTATION', { proxy_id: proxyId, triggered_by: triggeredBy });
  await updateProxyStatus(proxyId, 'CONNECTING');

  if (!agent.reconnect_supported) {
    const event = db.prepare(`
      INSERT INTO rotation_events(proxy_id, agent_id, triggered_by, old_ip, new_ip, result, duration_ms, created_at)
      VALUES(?,?,?,?,NULL,'RECONNECT_NOT_SUPPORTED',?,datetime('now'))
    `).run(proxyId, agent.id, triggeredBy, oldIp, Date.now() - t0);
    return { result: 'RECONNECT_NOT_SUPPORTED', old_ip: oldIp };
  }

  const cmdResult = await sendCommandToAgent(agent.id, 'ROTATE', { proxy_id: proxyId });
  if (!cmdResult.success && !cmdResult.queued) {
    db.prepare(`
      INSERT INTO rotation_events(proxy_id, agent_id, triggered_by, old_ip, result, error_message, duration_ms, created_at)
      VALUES(?,?,?,?,'ROTATION_FAILED',?,?,datetime('now'))
    `).run(proxyId, agent.id, triggeredBy, oldIp, 'Command dispatch failed', Date.now() - t0);
    return { result: 'ROTATION_FAILED', error: 'Command dispatch failed' };
  }

  return {
    result: 'ROTATION_INITIATED',
    old_ip: oldIp,
    proxy_id: proxyId,
    agent_id: agent.id,
    message: 'Rotation command sent to agent. Monitor status for IP change.',
  };
}

async function finalizeRotation(proxyId, agentId, newIp, oldIp, triggeredBy = 'AGENT') {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(proxyId);
  if (!proxy) return;

  const duration = Date.now();

  if (!newIp) {
    db.prepare(`
      INSERT INTO rotation_events(proxy_id, agent_id, triggered_by, old_ip, new_ip, result, created_at)
      VALUES(?,?,?,?,NULL,'IP_UNVERIFIED',datetime('now'))
    `).run(proxyId, agentId, triggeredBy, oldIp);
    notificationService.create('ROTATION_FAILED', 'WARNING', 'Rotation Failed', `Proxy ${proxy.name}: IP could not be verified`, agentId, proxyId);
    return;
  }

  const result = (oldIp && newIp === oldIp) ? 'IP_UNCHANGED' : 'SUCCESS';

  db.prepare(`
    INSERT INTO rotation_events(proxy_id, agent_id, triggered_by, old_ip, new_ip, result, created_at)
    VALUES(?,?,?,?,?,?,datetime('now'))
  `).run(proxyId, agentId, triggeredBy, oldIp, newIp, result);

  db.prepare(`
    INSERT INTO ip_history(agent_id, proxy_id, old_ip, new_ip, method, result, verification_status, ip_provider, created_at)
    VALUES(?,?,?,?,?,?,?,?,datetime('now'))
  `).run(agentId, proxyId, oldIp, newIp, triggeredBy === 'MANUAL' ? 'MANUAL' : 'AUTO', result, 'VERIFIED', 'proxy_egress_check');

  db.prepare(`
    UPDATE proxies SET current_public_ip=?, previous_ip=?, last_rotation=datetime('now'), updated_at=datetime('now') WHERE id=?
  `).run(newIp, oldIp, proxyId);

  if (result === 'SUCCESS') {
    notificationService.create('ROTATION_SUCCESS', 'INFO', 'Rotation Success', `Proxy ${proxy.name}: ${oldIp} → ${newIp}`, agentId, proxyId);
    logger.success(`Rotation success: ${proxy.name} ${oldIp} -> ${newIp}`, 'ROTATION', { proxy_id: proxyId });
  } else {
    notificationService.create('IP_UNCHANGED', 'WARNING', 'IP Unchanged', `Proxy ${proxy.name}: IP unchanged after rotation (${newIp})`, agentId, proxyId);
  }

  broadcast({ type: 'ROTATION_RESULT', proxyId, result, oldIp, newIp, timestamp: new Date().toISOString() });
}

async function autoRotationTick() {
  const db = getDb();
  const now = new Date();

  const proxies = db.prepare(`
    SELECT * FROM proxies WHERE rotation_mode IN ('INTERVAL','AUTO') AND status='ONLINE'
  `).all();

  for (const proxy of proxies) {
    const interval = proxy.rotation_interval_seconds || 3600;
    const lastRot = proxy.last_rotation ? new Date(proxy.last_rotation) : null;
    const elapsed = lastRot ? (now - lastRot) / 1000 : Infinity;

    if (elapsed >= interval) {
      logger.info(`Auto rotation triggered for ${proxy.name}`, 'ROTATION', { proxy_id: proxy.id });
      await rotateProxy(proxy.id, 'INTERVAL');
    }
  }
}

module.exports = { rotateProxy, finalizeRotation, autoRotationTick, sendCommandToAgent };
