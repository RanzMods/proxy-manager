'use strict';

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { getDb } = require('../utils/db');
const logger = require('../utils/logger');

const SALT_ROUNDS = 12;
const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_jwt_change_me_in_production_32chars_minimum';
const JWT_EXPIRES = process.env.JWT_EXPIRES || '8h';

async function hashPassword(password) {
  return bcrypt.hash(password, SALT_ROUNDS);
}

async function verifyPassword(password, hash) {
  return bcrypt.compare(password, hash);
}

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES });
}

function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

function hashAgentToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

async function authenticateAdmin(username, password) {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE username=?').get(username);
  if (!user) return null;
  const ok = await verifyPassword(password, user.password_hash);
  if (!ok) return null;
  db.prepare("UPDATE users SET last_login=datetime('now') WHERE id=?").run(user.id);
  return { id: user.id, username: user.username, role: user.role };
}

function authenticateAgentToken(rawToken) {
  const db = getDb();
  const hash = hashAgentToken(rawToken);
  const row = db.prepare(`
    SELECT at.*, a.id as agent_id, a.status as agent_status
    FROM agent_tokens at
    JOIN agents a ON a.id = at.agent_id
    WHERE at.token_hash=? AND at.revoked=0
  `).get(hash);
  if (!row) return null;
  if (row.expires_at && new Date(row.expires_at) < new Date()) return null;
  return row;
}

async function createAdminUser(username, password) {
  const db = getDb();
  const hash = await hashPassword(password);
  db.prepare(`
    INSERT INTO users(username, password_hash, role, created_at, updated_at)
    VALUES(?,?,'admin',datetime('now'),datetime('now'))
  `).run(username, hash);
  logger.info(`Admin user created: ${username}`, 'AUTH');
}

module.exports = {
  hashPassword,
  verifyPassword,
  signToken,
  verifyToken,
  hashAgentToken,
  authenticateAdmin,
  authenticateAgentToken,
  createAdminUser,
};
