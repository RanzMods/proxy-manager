'use strict';

const net = require('net');
const { getDb } = require('../utils/db');
const { detectProxyEgressIp } = require('./ipDetection');
const logger = require('../utils/logger');

async function tcpConnect(host, port, timeoutMs = 5000) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    const timer = setTimeout(() => { sock.destroy(); resolve(false); }, timeoutMs);
    sock.connect(port, host, () => { clearTimeout(timer); sock.destroy(); resolve(true); });
    sock.on('error', () => { clearTimeout(timer); resolve(false); });
  });
}

async function socks5Handshake(host, port, username, password, timeoutMs = 8000) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let step = 0;
    let buf = Buffer.alloc(0);

    const timer = setTimeout(() => {
      sock.destroy();
      resolve({ ok: false, error: 'timeout' });
    }, timeoutMs);

    const finish = (result) => {
      clearTimeout(timer);
      sock.destroy();
      resolve(result);
    };

    sock.connect(port, host, () => {
      sock.write(Buffer.from([0x05, 0x01, 0x02]));
      step = 1;
    });

    sock.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      if (step === 1 && buf.length >= 2) {
        if (buf[0] !== 0x05 || buf[1] !== 0x02) {
          return finish({ ok: false, auth_ok: false, error: 'auth method rejected' });
        }
        const user = Buffer.from(username, 'utf-8');
        const pass = Buffer.from(password, 'utf-8');
        const req = Buffer.concat([
          Buffer.from([0x01, user.length]),
          user,
          Buffer.from([pass.length]),
          pass,
        ]);
        sock.write(req);
        buf = Buffer.alloc(0);
        step = 2;
      } else if (step === 2 && buf.length >= 2) {
        if (buf[1] !== 0x00) {
          return finish({ ok: false, auth_ok: false, error: 'auth failed' });
        }
        const target = Buffer.from('1.1.1.1');
        const req = Buffer.concat([
          Buffer.from([0x05, 0x01, 0x00, 0x01]),
          Buffer.from([1, 1, 1, 1]),
          Buffer.from([0x00, 0x50]),
        ]);
        sock.write(req);
        buf = Buffer.alloc(0);
        step = 3;
      } else if (step === 3 && buf.length >= 4) {
        const rep = buf[1];
        finish({ ok: rep === 0x00, auth_ok: true, socks5_reply: rep });
      }
    });

    sock.on('error', (err) => finish({ ok: false, error: err.message }));
  });
}

async function fullHealthCheck(proxy) {
  const db = getDb();
  const cred = db.prepare('SELECT * FROM proxy_credentials WHERE proxy_id=?').get(proxy.id);
  if (!cred) {
    return { final_status: 'UNKNOWN', error_message: 'No credentials found' };
  }

  const username = cred.username;
  const decryptedPass = cred.password_plain;

  const result = {
    proxy_id: proxy.id,
    agent_id: proxy.agent_id,
    tcp_ok: 0,
    socks5_ok: 0,
    auth_ok: 0,
    outbound_ok: 0,
    dns_ok: 0,
    https_ok: 0,
    egress_ip: null,
    egress_ip_verified: 0,
    latency_ms: null,
    final_status: 'OFFLINE',
    error_message: null,
  };

  const host = proxy.listen_host === '0.0.0.0' ? '127.0.0.1' : proxy.listen_host;
  const port = proxy.listen_port;

  const t0 = Date.now();

  result.tcp_ok = (await tcpConnect(host, port)) ? 1 : 0;
  if (!result.tcp_ok) {
    result.final_status = 'OFFLINE';
    result.error_message = 'TCP connect failed';
    await saveHealthCheck(result);
    return result;
  }

  const socks = await socks5Handshake(host, port, username, decryptedPass || '');
  result.socks5_ok = socks.ok || socks.auth_ok !== undefined ? 1 : 0;
  result.auth_ok = socks.auth_ok ? 1 : 0;
  result.outbound_ok = socks.ok ? 1 : 0;

  if (!result.auth_ok) {
    result.final_status = 'OFFLINE';
    result.error_message = socks.error || 'SOCKS5 auth failed';
    await saveHealthCheck(result);
    return result;
  }

  const egressResult = await detectProxyEgressIp(host, port, username, decryptedPass || '');
  if (egressResult.ip) {
    result.egress_ip = egressResult.ip;
    result.egress_ip_verified = 1;
    result.https_ok = 1;
    result.dns_ok = 1;
    result.outbound_ok = 1;
  } else if (egressResult.status === 'IP_CONFLICT') {
    result.egress_ip = null;
    result.egress_ip_verified = 0;
    result.error_message = 'IP conflict detected';
    result.final_status = 'WARNING';
  }

  result.latency_ms = Date.now() - t0;

  if (result.tcp_ok && result.socks5_ok && result.auth_ok && result.outbound_ok) {
    result.final_status = result.egress_ip_verified ? 'ONLINE' : 'WARNING';
  } else if (result.tcp_ok && result.auth_ok) {
    result.final_status = 'WARNING';
  } else {
    result.final_status = 'OFFLINE';
  }

  await saveHealthCheck(result);
  return result;
}

async function saveHealthCheck(result) {
  try {
    const db = getDb();
    db.prepare(`
      INSERT INTO health_checks(
        proxy_id, agent_id, tcp_ok, socks5_ok, auth_ok, outbound_ok,
        dns_ok, https_ok, egress_ip, egress_ip_verified, latency_ms,
        final_status, error_message, created_at
      ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
    `).run(
      result.proxy_id, result.agent_id,
      result.tcp_ok, result.socks5_ok, result.auth_ok, result.outbound_ok,
      result.dns_ok, result.https_ok, result.egress_ip, result.egress_ip_verified,
      result.latency_ms, result.final_status, result.error_message
    );
  } catch (err) {
    logger.error(`Failed to save health check: ${err.message}`, 'HEALTH');
  }
}

module.exports = { fullHealthCheck, tcpConnect, socks5Handshake };
