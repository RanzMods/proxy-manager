'use strict';

const { getDb } = require('../utils/db');
const { broadcast } = require('./sseManager');

function create(type, level, title, message, agentId = null, proxyId = null) {
  try {
    const db = getDb();
    const row = db.prepare(`
      INSERT INTO notifications(type, level, title, message, agent_id, proxy_id, read, created_at)
      VALUES(?,?,?,?,?,?,0,datetime('now'))
    `).run(type, level, title, message, agentId, proxyId);
    const notif = {
      id: row.lastInsertRowid,
      type, level, title, message, agentId, proxyId,
      read: false,
      created_at: new Date().toISOString(),
    };
    broadcast({ type: 'NOTIFICATION', notification: notif });
    return notif;
  } catch (_) {}
}

function getUnread(limit = 50) {
  const db = getDb();
  return db.prepare('SELECT * FROM notifications WHERE read=0 ORDER BY created_at DESC LIMIT ?').all(limit);
}

function markRead(id) {
  const db = getDb();
  db.prepare('UPDATE notifications SET read=1 WHERE id=?').run(id);
}

function markAllRead() {
  const db = getDb();
  db.prepare('UPDATE notifications SET read=1').run();
}

module.exports = { create, getUnread, markRead, markAllRead };
