'use strict';

const { getDb } = require('../utils/db');
const { getSetting, isStale, dataAge } = require('../utils/helpers');
const { broadcast } = require('./sseManager');
const notificationService = require('./notificationService');
const logger = require('../utils/logger');

const VALID_STATUSES = ['ONLINE','WARNING','OFFLINE','CONNECTING','UNKNOWN','STALE','UNVERIFIED'];

function computeAgentStatus(agent) {
  if (!agent.last_heartbeat) return 'UNKNOWN';
  const staleThresh = parseInt(getSetting('stale_data_threshold_seconds', '120'), 10);
  const timeoutSec = parseInt(getSetting('heartbeat_timeout_seconds', '30'), 10);
  const maxFail = parseInt(getSetting('heartbeat_max_failures', '3'), 10);

  const age = dataAge(agent.last_heartbeat);
  if (age === null) return 'UNKNOWN';
  if (age > staleThresh) return 'STALE';
  if (agent.consecutive_failures >= maxFail) return 'OFFLINE';
  if (agent.consecutive_failures >= 1) return 'WARNING';
  if (age > timeoutSec) return 'OFFLINE';
  return 'ONLINE';
}

function computeProxyStatus(proxy, latestHealthCheck, agent) {
  if (!agent) return 'UNKNOWN';

  const agentStatus = computeAgentStatus(agent);
  if (agentStatus === 'OFFLINE' || agentStatus === 'STALE') return 'OFFLINE';
  if (agentStatus === 'UNKNOWN') return 'UNKNOWN';

  if (!latestHealthCheck) return 'UNKNOWN';

  const staleThresh = parseInt(getSetting('stale_data_threshold_seconds', '120'), 10);
  const age = dataAge(latestHealthCheck.created_at);
  if (age === null) return 'UNKNOWN';

  const hcInterval = (proxy.health_check_interval_seconds || 60);
  if (age > Math.max(staleThresh, hcInterval * 2)) return 'STALE';

  if (!latestHealthCheck.egress_ip_verified) {
    if (latestHealthCheck.final_status === 'ONLINE') return 'UNVERIFIED';
  }

  return latestHealthCheck.final_status || 'UNKNOWN';
}

async function updateAgentStatus(agentId, newStatus, extraFields = {}) {
  const db = getDb();
  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(agentId);
  if (!agent) return;

  const oldStatus = agent.status;

  db.prepare(`
    UPDATE agents SET status=?, updated_at=datetime('now') ${
      Object.keys(extraFields).map(k => `, ${k}=?`).join('')
    } WHERE id=?
  `).run(newStatus, ...Object.values(extraFields), agentId);

  if (oldStatus !== newStatus) {
    logger.info(`Agent ${agentId} status: ${oldStatus} -> ${newStatus}`, 'STATUS_ENGINE', { agent_id: agentId });

    if (newStatus === 'OFFLINE' && oldStatus !== 'OFFLINE') {
      notificationService.create('AGENT_OFFLINE', 'WARNING', 'Agent Offline', `Agent ${agent.name} went offline`, agentId, null);
    } else if (newStatus === 'ONLINE' && (oldStatus === 'OFFLINE' || oldStatus === 'UNKNOWN')) {
      notificationService.create('AGENT_ONLINE', 'INFO', 'Agent Online', `Agent ${agent.name} is online`, agentId, null);
    }

    broadcast({ type: 'AGENT_STATUS', agentId, oldStatus, newStatus, timestamp: new Date().toISOString() });
  }
}

async function updateProxyStatus(proxyId, newStatus, extraFields = {}) {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(proxyId);
  if (!proxy) return;

  const oldStatus = proxy.status;

  const fieldStr = Object.keys(extraFields).map(k => `, ${k}=?`).join('');
  db.prepare(`
    UPDATE proxies SET status=?, updated_at=datetime('now')${fieldStr} WHERE id=?
  `).run(newStatus, ...Object.values(extraFields), proxyId);

  if (oldStatus !== newStatus) {
    db.prepare(`
      INSERT INTO proxy_events(proxy_id, agent_id, event_type, old_status, new_status, created_at)
      VALUES(?,?,?,?,?,datetime('now'))
    `).run(proxyId, proxy.agent_id, 'STATUS_CHANGE', oldStatus, newStatus);

    logger.info(`Proxy ${proxy.name} status: ${oldStatus} -> ${newStatus}`, 'STATUS_ENGINE', { proxy_id: proxyId });

    if (newStatus === 'OFFLINE' && oldStatus !== 'OFFLINE') {
      notificationService.create('PROXY_OFFLINE', 'ERROR', 'Proxy Offline', `Proxy ${proxy.name} went offline`, proxy.agent_id, proxyId);
    } else if (newStatus === 'ONLINE' && oldStatus !== 'ONLINE') {
      notificationService.create('PROXY_ONLINE', 'INFO', 'Proxy Online', `Proxy ${proxy.name} is online`, proxy.agent_id, proxyId);
    }

    broadcast({ type: 'PROXY_STATUS', proxyId, proxyName: proxy.name, oldStatus, newStatus, timestamp: new Date().toISOString() });
  }
}

function aggregateStatus() {
  const db = getDb();
  const agents = db.prepare('SELECT * FROM agents').all();
  for (const agent of agents) {
    const computed = computeAgentStatus(agent);
    if (computed !== agent.status) {
      updateAgentStatus(agent.id, computed);
    }
  }

  const proxies = db.prepare('SELECT * FROM proxies').all();
  for (const proxy of proxies) {
    const agent = proxy.agent_id ? db.prepare('SELECT * FROM agents WHERE id=?').get(proxy.agent_id) : null;
    const hc = db.prepare('SELECT * FROM health_checks WHERE proxy_id=? ORDER BY created_at DESC LIMIT 1').get(proxy.id);
    const computed = computeProxyStatus(proxy, hc, agent);
    if (computed !== proxy.status) {
      const extra = hc ? { latency_ms: hc.latency_ms, last_health_check: hc.created_at } : {};
      if (hc?.egress_ip) extra.current_public_ip = hc.egress_ip;
      updateProxyStatus(proxy.id, computed, extra);
    }
  }
}

module.exports = { computeAgentStatus, computeProxyStatus, updateAgentStatus, updateProxyStatus, aggregateStatus };
