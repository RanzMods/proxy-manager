'use strict';

const axios = require('axios');
const { SocksProxyAgent } = require('socks');
const { getDb } = require('../utils/db');
const { getSetting, safeJson } = require('../utils/helpers');
const logger = require('../utils/logger');

const DEFAULT_PROVIDERS = [
  { url: 'https://api.ipify.org?format=json', field: 'ip' },
  { url: 'https://api4.my-ip.io/ip.json', field: 'ip' },
  { url: 'https://ipapi.co/json/', field: 'ip' },
];

function getProviders() {
  const raw = getSetting('ip_providers');
  if (!raw) return DEFAULT_PROVIDERS;
  const parsed = safeJson(raw);
  if (!Array.isArray(parsed)) return DEFAULT_PROVIDERS;
  return parsed.map(p => {
    if (typeof p === 'string') return { url: p, field: 'ip' };
    return p;
  });
}

async function fetchIpFromProvider(provider, axiosOptions = {}) {
  const resp = await axios.get(provider.url, {
    timeout: 8000,
    ...axiosOptions,
  });
  const data = resp.data;
  if (typeof data === 'string') return data.trim();
  return data[provider.field || 'ip']?.trim() || null;
}

async function detectPublicIp(axiosOptions = {}) {
  const providers = getProviders();
  const results = [];
  let lastError = null;

  for (const provider of providers) {
    try {
      const ip = await fetchIpFromProvider(provider, axiosOptions);
      if (ip && isValidIp(ip)) {
        results.push({ ip, provider: provider.url });
        if (results.length >= 2) break;
      }
    } catch (err) {
      lastError = err;
      logger.warn(`IP provider failed: ${provider.url}: ${err.message}`, 'IP_DETECTION');
    }
  }

  if (results.length === 0) {
    return {
      ip: null,
      status: 'FAILED',
      provider: null,
      confidence: 0,
      error: lastError?.message,
    };
  }

  if (results.length >= 2 && results[0].ip !== results[1].ip) {
    logger.warn(`IP conflict detected: ${results[0].ip} vs ${results[1].ip}`, 'IP_DETECTION');
    return {
      ip: null,
      status: 'IP_CONFLICT',
      provider: results[0].provider,
      confidence: 0,
      candidates: results.map(r => r.ip),
    };
  }

  return {
    ip: results[0].ip,
    status: 'OK',
    provider: results[0].provider,
    confidence: results.length,
  };
}

async function detectProxyEgressIp(proxyHost, proxyPort, proxyUser, proxyPass) {
  const providers = getProviders();
  const results = [];

  const agentUrl = `socks5://${encodeURIComponent(proxyUser)}:${encodeURIComponent(proxyPass)}@${proxyHost}:${proxyPort}`;
  const agent = new SocksProxyAgent(agentUrl);

  for (const provider of providers) {
    try {
      const ip = await fetchIpFromProvider(provider, {
        httpAgent: agent,
        httpsAgent: agent,
      });
      if (ip && isValidIp(ip)) {
        results.push({ ip, provider: provider.url });
        if (results.length >= 2) break;
      }
    } catch (err) {
      logger.warn(`Egress IP check via proxy failed: ${provider.url}: ${err.message}`, 'IP_DETECTION');
    }
  }

  if (results.length === 0) {
    return { ip: null, status: 'FAILED', provider: null, confidence: 0 };
  }

  if (results.length >= 2 && results[0].ip !== results[1].ip) {
    return {
      ip: null,
      status: 'IP_CONFLICT',
      provider: results[0].provider,
      confidence: 0,
      candidates: results.map(r => r.ip),
    };
  }

  return {
    ip: results[0].ip,
    status: 'OK',
    provider: results[0].provider,
    confidence: results.length,
  };
}

function isValidIp(ip) {
  const v4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  const v6 = /^[a-fA-F0-9:]+$/;
  return v4.test(ip) || v6.test(ip);
}

module.exports = { detectPublicIp, detectProxyEgressIp, isValidIp };
