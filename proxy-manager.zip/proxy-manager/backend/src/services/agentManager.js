'use strict';

const { getDb } = require('../utils/db');
const { getSetting } = require('../utils/helpers');
const { updateAgentStatus } = require('./statusEngine');
const { broadcast } = require('./sseManager');
const notificationService = require('./notificationService');
const logger = require('../utils/logger');

async function processHeartbeat(agentId, data) {
  const db = getDb();
  const maxFail = parseInt(getSetting('heartbeat_max_failures', '3'), 10);

  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(agentId);
  if (!agent) return null;

  const now = new Date().toISOString();
  const latency = data.latency_ms || null;

  db.prepare(`
    INSERT INTO heartbeat_events(agent_id, public_ip, network_type, proxy_status, uptime_seconds, latency_ms, received_at)
    VALUES(?,?,?,?,?,?,datetime('now'))
  `).run(agentId, data.public_ip || null, data.network_type || null, JSON.stringify(data.proxy_status || {}), data.uptime_seconds || 0, latency);

  const previousIp = agent.public_ip;
  const newIp = data.public_ip || null;
  const ipChanged = newIp && previousIp && newIp !== previousIp;

  db.prepare(`
    UPDATE agents SET
      last_heartbeat=datetime('now'),
      heartbeat_latency_ms=?,
      consecutive_failures=0,
      uptime_seconds=?,
      public_ip=?,
      network_type=?,
      carrier=?,
      updated_at=datetime('now')
    WHERE id=?
  `).run(
    latency,
    data.uptime_seconds || 0,
    newIp || agent.public_ip,
    data.network_type || agent.network_type,
    data.carrier || agent.carrier,
    agentId
  );

  if (ipChanged) {
    db.prepare(`
      UPDATE agents SET previous_ip=? WHERE id=?
    `).run(previousIp, agentId);

    db.prepare(`
      INSERT INTO ip_history(agent_id, proxy_id, old_ip, new_ip, method, result, verification_status, created_at)
      VALUES(?,NULL,?,?,'AUTO','IP_CHANGED','UNVERIFIED',datetime('now'))
    `).run(agentId, previousIp, newIp);

    notificationService.create('IP_CHANGED', 'INFO', 'IP Changed', `Agent ${agent.name}: ${previousIp} → ${newIp}`, agentId, null);
    broadcast({ type: 'IP_CHANGE', agentId, agentName: agent.name, oldIp: previousIp, newIp, timestamp: now });
    logger.info(`Agent ${agent.name} IP changed: ${previousIp} -> ${newIp}`, 'HEARTBEAT', { agent_id: agentId });
  }

  await updateAgentStatus(agentId, 'ONLINE');

  // Real-time Traffic Usage Handling
  if (data.traffic) {
    const bytesIn = Number(data.traffic.bytes_in) || 0;
    const bytesOut = Number(data.traffic.bytes_out) || 0;
    const totalBytes = Number(data.traffic.total_bytes) || (bytesIn + bytesOut);
    const activeConns = Number(data.traffic.active_connections) || 0;

    db.prepare(`
      UPDATE agents SET
        bytes_in=?,
        bytes_out=?,
        total_bytes=?
      WHERE id=?
    `).run(bytesIn, bytesOut, totalBytes, agentId);

    db.prepare(`
      UPDATE proxies SET
        bytes_in=?,
        bytes_out=?,
        total_bytes=?
      WHERE agent_id=?
    `).run(bytesIn, bytesOut, totalBytes, agentId);

    if (totalBytes > 0) {
      db.prepare(`
        INSERT INTO traffic_history(agent_id, proxy_id, bytes_in, bytes_out, total_bytes, recorded_at)
        VALUES(?, (SELECT id FROM proxies WHERE agent_id=? LIMIT 1), ?, ?, ?, datetime('now'))
      `).run(agentId, agentId, bytesIn, bytesOut, totalBytes);
    }

    broadcast({
      type: 'TRAFFIC_UPDATE',
      agentId,
      traffic: {
        bytes_in: bytesIn,
        bytes_out: bytesOut,
        total_bytes: totalBytes,
        active_connections: activeConns,
      },
      timestamp: now,
    });
  }

  broadcast({ type: 'HEARTBEAT', agentId, timestamp: now, publicIp: newIp || agent.public_ip, networkType: data.network_type });

  return { received: true, timestamp: now };
}

async function recordAgentFailure(agentId) {
  const db = getDb();
  const maxFail = parseInt(getSetting('heartbeat_max_failures', '3'), 10);

  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(agentId);
  if (!agent) return;

  const newFail = (agent.consecutive_failures || 0) + 1;
  db.prepare('UPDATE agents SET consecutive_failures=?, updated_at=datetime(\'now\') WHERE id=?').run(newFail, agentId);

  if (newFail === 1) {
    await updateAgentStatus(agentId, 'WARNING');
  } else if (newFail >= maxFail) {
    await updateAgentStatus(agentId, 'OFFLINE');
  }
}

module.exports = { processHeartbeat, recordAgentFailure };
