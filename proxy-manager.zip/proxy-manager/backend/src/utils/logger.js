'use strict';

const winston = require('winston');
const path = require('path');
const { getDb } = require('./db');

const LOG_DIR = process.env.LOG_DIR || path.join(__dirname, '../../../logs');

const consoleFormat = winston.format.combine(
  winston.format.colorize(),
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.printf(({ timestamp, level, message, component, ...meta }) => {
    const comp = component ? `[${component}]` : '';
    const extra = Object.keys(meta).length ? ' ' + JSON.stringify(meta) : '';
    return `${timestamp} ${level} ${comp} ${message}${extra}`;
  })
);

const fileFormat = winston.format.combine(
  winston.format.timestamp(),
  winston.format.json()
);

const winstonLogger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  transports: [
    new winston.transports.Console({ format: consoleFormat }),
    new (require('winston-daily-rotate-file'))({
      dirname: LOG_DIR,
      filename: 'proxy-manager-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxFiles: `${process.env.LOG_RETENTION_DAYS || 30}d`,
      format: fileFormat,
    }),
  ],
});

function persistLog(level, component, message, meta = {}) {
  try {
    const db = getDb();
    const retention = (() => {
      try {
        const s = db.prepare("SELECT value FROM settings WHERE key='log_retention_days'").get();
        return parseInt(s?.value || '30', 10);
      } catch { return 30; }
    })();

    db.prepare(`
      INSERT INTO logs(level, component, agent_id, proxy_id, ip, message, metadata, created_at)
      VALUES(?,?,?,?,?,?,?,datetime('now'))
    `).run(
      level.toUpperCase(),
      component,
      meta.agent_id || null,
      meta.proxy_id || null,
      meta.ip || null,
      message,
      meta ? JSON.stringify(meta) : null
    );

    db.prepare(`
      DELETE FROM logs WHERE created_at < datetime('now', '-' || ? || ' days')
    `).run(retention);
  } catch (_) {}
}

const logger = {
  info: (msg, component = 'SYSTEM', meta = {}) => {
    winstonLogger.info(msg, { component, ...meta });
    persistLog('INFO', component, msg, meta);
  },
  success: (msg, component = 'SYSTEM', meta = {}) => {
    winstonLogger.info(msg, { component, level_tag: 'SUCCESS', ...meta });
    persistLog('SUCCESS', component, msg, meta);
  },
  warn: (msg, component = 'SYSTEM', meta = {}) => {
    winstonLogger.warn(msg, { component, ...meta });
    persistLog('WARNING', component, msg, meta);
  },
  error: (msg, component = 'SYSTEM', meta = {}) => {
    winstonLogger.error(msg, { component, ...meta });
    persistLog('ERROR', component, msg, meta);
  },
};

module.exports = logger;
