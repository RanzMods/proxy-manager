#!/usr/bin/env node
'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '../../../database/proxy-manager.db');
const MIGRATIONS_DIR = path.join(__dirname, '../../../database/migrations');

function ensureDir(p) {
  const dir = path.dirname(p);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function migrate() {
  ensureDir(DB_PATH);
  const db = new Database(DB_PATH);

  db.pragma('journal_mode=WAL');
  db.pragma('foreign_keys=ON');
  db.pragma('busy_timeout=5000');

  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  const applied = new Set(
    db.prepare('SELECT version FROM schema_migrations').all().map(r => r.version)
  );

  const files = fs.readdirSync(MIGRATIONS_DIR)
    .filter(f => f.endsWith('.sql'))
    .sort();

  let count = 0;
  for (const file of files) {
    const version = file.replace('.sql', '');
    if (applied.has(version)) continue;

    const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf-8');
    console.log(`Applying migration: ${file}`);
    db.exec(sql);
    db.prepare('INSERT INTO schema_migrations(version) VALUES(?)').run(version);
    count++;
  }

  if (count === 0) {
    console.log('All migrations already applied.');
  } else {
    console.log(`Applied ${count} migration(s).`);
  }

  db.close();
}

migrate();
