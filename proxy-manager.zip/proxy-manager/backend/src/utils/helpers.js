'use strict';

const crypto = require('crypto');
const { getDb } = require('./db');

function getSetting(key, defaultValue = null) {
  try {
    const db = getDb();
    const row = db.prepare('SELECT value FROM settings WHERE key=?').get(key);
    return row ? row.value : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setSetting(key, value) {
  const db = getDb();
  db.prepare(`
    INSERT INTO settings(key, value, updated_at) VALUES(?,?,datetime('now'))
    ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
  `).run(key, String(value));
}

function generateToken(length = 48) {
  return crypto.randomBytes(length).toString('hex');
}

function generateId() {
  const { v4: uuidv4 } = require('uuid');
  return uuidv4();
}

function dataAge(timestampStr) {
  if (!timestampStr) return null;
  const ts = new Date(timestampStr).getTime();
  if (isNaN(ts)) return null;
  return Math.floor((Date.now() - ts) / 1000);
}

function isStale(timestampStr, thresholdSeconds = null) {
  const db = getDb();
  const thresh = thresholdSeconds ||
    parseInt(getSetting('stale_data_threshold_seconds', '120'), 10);
  const age = dataAge(timestampStr);
  if (age === null) return true;
  return age > thresh;
}

function safeJson(str, fallback = null) {
  try { return JSON.parse(str); } catch { return fallback; }
}

module.exports = { getSetting, setSetting, generateToken, generateId, dataAge, isStale, safeJson };
