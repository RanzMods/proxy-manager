'use strict';

const path = require('path');
const Database = require('better-sqlite3');

let _db = null;

function getDb() {
  if (_db) return _db;
  const dbPath = process.env.DB_PATH || path.join(__dirname, '../../../database/proxy-manager.db');
  _db = new Database(dbPath);
  _db.pragma('journal_mode=WAL');
  _db.pragma('foreign_keys=ON');
  _db.pragma('busy_timeout=5000');
  return _db;
}

module.exports = { getDb };
