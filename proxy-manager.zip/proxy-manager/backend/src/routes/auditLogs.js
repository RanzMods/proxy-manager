'use strict';

const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const { getDb } = require('../utils/db');

router.get('/', requireAdmin, (req, res) => {
  const db = getDb();
  const page = parseInt(req.query.page || '1', 10);
  const limit = Math.min(parseInt(req.query.limit || '50', 10), 100);
  const offset = (page - 1) * limit;

  const total = db.prepare('SELECT COUNT(*) as c FROM audit_logs').get().c;
  const logs = db.prepare(`
    SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(limit, offset);

  res.json({
    data: logs,
    pagination: { page, limit, total, pages: Math.ceil(total / limit) },
  });
});

module.exports = router;
