'use strict';

const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const { getDb } = require('../utils/db');

router.get('/', requireAdmin, (req, res) => {
  const db = getDb();

  const dailyRotations = db.prepare(`
    SELECT date(created_at) as day,
      COUNT(*) as total,
      SUM(CASE WHEN result='SUCCESS' THEN 1 ELSE 0 END) as success,
      SUM(CASE WHEN result NOT IN ('SUCCESS','IP_UNCHANGED') THEN 1 ELSE 0 END) as failed,
      SUM(CASE WHEN result='IP_UNCHANGED' THEN 1 ELSE 0 END) as unchanged
    FROM rotation_events
    WHERE created_at >= datetime('now', '-30 days')
    GROUP BY date(created_at)
    ORDER BY day ASC
  `).all();

  const dailyIpChanges = db.prepare(`
    SELECT date(created_at) as day, COUNT(*) as count
    FROM ip_history
    WHERE created_at >= datetime('now', '-30 days')
    GROUP BY date(created_at)
    ORDER BY day ASC
  `).all();

  const latencyHistory = db.prepare(`
    SELECT strftime('%Y-%m-%d %H:00', created_at) as hour,
      AVG(latency_ms) as avg_latency
    FROM health_checks
    WHERE created_at >= datetime('now', '-24 hours') AND latency_ms IS NOT NULL
    GROUP BY hour
    ORDER BY hour ASC
  `).all();

  res.json({
    daily_rotations: dailyRotations,
    daily_ip_changes: dailyIpChanges,
    latency_history: latencyHistory,
  });
});

module.exports = router;
