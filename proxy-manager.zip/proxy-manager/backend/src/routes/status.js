'use strict';

const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const { getDb } = require('../utils/db');
const { getSetting } = require('../utils/helpers');

router.get('/', requireAdmin, (req, res) => {
  const db = getDb();

  const totalProxies = db.prepare('SELECT COUNT(*) as c FROM proxies').get().c;
  const proxyOnline = db.prepare("SELECT COUNT(*) as c FROM proxies WHERE status='ONLINE'").get().c;
  const proxyWarning = db.prepare("SELECT COUNT(*) as c FROM proxies WHERE status='WARNING'").get().c;
  const proxyOffline = db.prepare("SELECT COUNT(*) as c FROM proxies WHERE status='OFFLINE'").get().c;
  const proxyUnknown = db.prepare("SELECT COUNT(*) as c FROM proxies WHERE status IN ('UNKNOWN','STALE','UNVERIFIED')").get().c;

  const totalAgents = db.prepare('SELECT COUNT(*) as c FROM agents').get().c;
  const agentOnline = db.prepare("SELECT COUNT(*) as c FROM agents WHERE status='ONLINE'").get().c;
  const agentOffline = db.prepare("SELECT COUNT(*) as c FROM agents WHERE status='OFFLINE'").get().c;

  const totalRotations = db.prepare('SELECT COUNT(*) as c FROM rotation_events').get().c;
  const successRotations = db.prepare("SELECT COUNT(*) as c FROM rotation_events WHERE result='SUCCESS'").get().c;
  const failedRotations = db.prepare("SELECT COUNT(*) as c FROM rotation_events WHERE result NOT IN ('SUCCESS','IP_UNCHANGED')").get().c;
  const unchangedRotations = db.prepare("SELECT COUNT(*) as c FROM rotation_events WHERE result='IP_UNCHANGED'").get().c;

  const avgLatency = db.prepare('SELECT AVG(latency_ms) as avg FROM proxies WHERE latency_ms IS NOT NULL').get().avg || 0;
  const totalUptime = db.prepare('SELECT SUM(uptime_seconds) as sum FROM proxies').get().sum || 0;

  const activeMobileIps = db.prepare(`
    SELECT DISTINCT public_ip FROM agents WHERE public_ip IS NOT NULL AND status='ONLINE'
  `).all().map(r => r.public_ip);

  const lastIpChange = db.prepare(`
    SELECT * FROM ip_history ORDER BY created_at DESC LIMIT 1
  `).get();

  const recentEvents = db.prepare(`
    SELECT 'rotation' as src, created_at, result as detail, proxy_id as ref FROM rotation_events
    UNION ALL
    SELECT 'status' as src, created_at, event_type as detail, proxy_id as ref FROM proxy_events
    ORDER BY created_at DESC LIMIT 10
  `).all();

  const trafficStats = db.prepare(`
    SELECT
      COALESCE(SUM(bytes_in), 0) as bytes_in,
      COALESCE(SUM(bytes_out), 0) as bytes_out,
      COALESCE(SUM(total_bytes), 0) as total_bytes
    FROM agents
  `).get();

  res.json({
    proxies: {
      total: totalProxies,
      online: proxyOnline,
      warning: proxyWarning,
      offline: proxyOffline,
      unknown: proxyUnknown,
    },
    agents: {
      total: totalAgents,
      online: agentOnline,
      offline: agentOffline,
    },
    rotations: {
      total: totalRotations,
      success: successRotations,
      failed: failedRotations,
      unchanged: unchangedRotations,
      success_rate: totalRotations ? ((successRotations / totalRotations) * 100).toFixed(1) : 0,
    },
    traffic: {
      bytes_in: trafficStats.bytes_in,
      bytes_out: trafficStats.bytes_out,
      total_bytes: trafficStats.total_bytes,
    },
    metrics: {
      average_latency_ms: Math.round(avgLatency),
      total_uptime_seconds: totalUptime,
      active_mobile_ips: activeMobileIps,
      last_ip_change: lastIpChange,
    },
    recent_events: recentEvents,
    timestamp: new Date().toISOString(),
  });
});

module.exports = router;
