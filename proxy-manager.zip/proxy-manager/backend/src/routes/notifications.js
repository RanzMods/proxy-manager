'use strict';

const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const notificationService = require('../services/notificationService');

router.get('/', requireAdmin, (req, res) => {
  const limit = parseInt(req.query.limit || '50', 10);
  res.json(notificationService.getUnread(limit));
});

router.post('/:id/read', requireAdmin, (req, res) => {
  notificationService.markRead(req.params.id);
  res.json({ success: true });
});

router.post('/read-all', requireAdmin, (req, res) => {
  notificationService.markAllRead();
  res.json({ success: true });
});

module.exports = router;
