'use strict';

const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const { getDb } = require('../utils/db');

router.get('/', requireAdmin, (req, res) => {
  const db = getDb();
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '50', 10);
  const offset = (page - 1) * limit;

  const agentId = req.query.agent_id;
  const proxyId = req.query.proxy_id;
  const result = req.query.result;

  let where = 'WHERE 1=1';
  const params = [];
  if (agentId) { where += ' AND h.agent_id=?'; params.push(agentId); }
  if (proxyId) { where += ' AND h.proxy_id=?'; params.push(proxyId); }
  if (result) { where += ' AND h.result=?'; params.push(result); }

  const total = db.prepare(`SELECT COUNT(*) as c FROM ip_history h ${where}`).get(...params).c;

  const rows = db.prepare(`
    SELECT h.*, a.name as agent_name, p.name as proxy_name
    FROM ip_history h
    LEFT JOIN agents a ON a.id=h.agent_id
    LEFT JOIN proxies p ON p.id=h.proxy_id
    ${where}
    ORDER BY h.created_at DESC
    LIMIT ? OFFSET ?
  `).all(...params, limit, offset);

  res.json({
    data: rows,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit),
    },
  });
});

module.exports = router;
