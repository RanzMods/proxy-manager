'use strict';

const express = require('express');
const router = express.Router();
const { requireAdmin, auditLog } = require('../middleware/auth');
const { getDb } = require('../utils/db');
const { getSetting, setSetting } = require('../utils/helpers');

router.get('/', requireAdmin, (req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const settings = {};
  for (const r of rows) settings[r.key] = r.value;
  res.json(settings);
});

router.put('/', requireAdmin, auditLog('UPDATE_SETTINGS', 'settings', null), (req, res) => {
  const allowedKeys = [
    'dashboard_name','timezone','heartbeat_interval_seconds','heartbeat_timeout_seconds',
    'heartbeat_max_failures','health_check_interval_seconds','default_proxy_port',
    'default_rotation_interval_seconds','log_retention_days','ip_providers',
    'ip_conflict_threshold','auto_restart_on_failure','telegram_enabled',
    'telegram_bot_token','telegram_chat_id','discord_enabled','discord_webhook_url',
    'email_enabled','stale_data_threshold_seconds',
  ];

  const db = getDb();
  const updates = {};
  for (const [key, value] of Object.entries(req.body)) {
    if (allowedKeys.includes(key)) {
      setSetting(key, typeof value === 'object' ? JSON.stringify(value) : String(value));
      updates[key] = value;
    }
  }

  res.json({ success: true, updated: updates });
});

module.exports = router;
