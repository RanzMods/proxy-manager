'use strict';

const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const { getDb } = require('../utils/db');

router.get('/', requireAdmin, (req, res) => {
  const db = getDb();
  const page = parseInt(req.query.page || '1', 10);
  const limit = Math.min(parseInt(req.query.limit || '100', 10), 200);
  const offset = (page - 1) * limit;

  const level = req.query.level;
  const component = req.query.component;
  const agentId = req.query.agent_id;
  const proxyId = req.query.proxy_id;

  let where = 'WHERE 1=1';
  const params = [];
  if (level) { where += ' AND level=?'; params.push(level.toUpperCase()); }
  if (component) { where += ' AND component=?'; params.push(component); }
  if (agentId) { where += ' AND agent_id=?'; params.push(agentId); }
  if (proxyId) { where += ' AND proxy_id=?'; params.push(proxyId); }

  const total = db.prepare(`SELECT COUNT(*) as c FROM logs ${where}`).get(...params).c;

  const rows = db.prepare(`
    SELECT * FROM logs ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(...params, limit, offset);

  res.json({
    data: rows,
    pagination: { page, limit, total, pages: Math.ceil(total / limit) },
  });
});

module.exports = router;
