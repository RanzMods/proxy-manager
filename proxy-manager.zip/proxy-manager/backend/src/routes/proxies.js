'use strict';

const express = require('express');
const router = express.Router();
const { requireAdmin, auditLog } = require('../middleware/auth');
const { proxyRules } = require('../middleware/validator');
const { getDb } = require('../utils/db');
const { generateId, getSetting, dataAge } = require('../utils/helpers');
const { hashPassword } = require('../services/auth');
const bcrypt = require('bcrypt');
const { fullHealthCheck } = require('../services/healthChecker');
const { rotateProxy } = require('../services/rotationManager');
const { updateProxyStatus } = require('../services/statusEngine');
const { sendCommandToAgent } = require('../services/rotationManager');
const logger = require('../utils/logger');

router.get('/', requireAdmin, (req, res) => {
  const db = getDb();
  const proxies = db.prepare(`
    SELECT p.*, a.name as agent_name, a.status as agent_status,
      pc.username as proxy_username,
      (SELECT final_status FROM health_checks WHERE proxy_id=p.id ORDER BY created_at DESC LIMIT 1) as last_hc_status,
      (SELECT egress_ip FROM health_checks WHERE proxy_id=p.id ORDER BY created_at DESC LIMIT 1) as last_egress_ip,
      (SELECT latency_ms FROM health_checks WHERE proxy_id=p.id ORDER BY created_at DESC LIMIT 1) as last_latency_ms
    FROM proxies p
    LEFT JOIN agents a ON a.id=p.agent_id
    LEFT JOIN proxy_credentials pc ON pc.proxy_id=p.id
    ORDER BY p.created_at ASC
  `).all();

  res.json(proxies.map(p => ({
    ...p,
    data_age_seconds: dataAge(p.last_health_check),
  })));
});

router.post('/', requireAdmin, ...proxyRules.create, auditLog('CREATE_PROXY', 'proxy', null), async (req, res) => {
  const db = getDb();
  const { name, type = 'SOCKS5', listen_host = '0.0.0.0', listen_port, agent_id,
    username, password, rotation_mode = 'DISABLED',
    rotation_interval_seconds = 3600, health_check_interval_seconds = 60 } = req.body;

  const existing = db.prepare('SELECT id FROM proxies WHERE listen_port=?').get(listen_port);
  if (existing) return res.status(409).json({ error: 'Port already in use' });

  const nameExist = db.prepare('SELECT id FROM proxies WHERE name=?').get(name);
  if (nameExist) return res.status(409).json({ error: 'Proxy name already exists' });

  if (agent_id) {
    const agent = db.prepare('SELECT id FROM agents WHERE id=?').get(agent_id);
    if (!agent) return res.status(404).json({ error: 'Agent not found' });
  }

  const id = generateId();
  const passHash = await bcrypt.hash(password, 12);

  db.prepare(`
    INSERT INTO proxies(id, name, type, listen_host, listen_port, agent_id, status,
      rotation_mode, rotation_interval_seconds, health_check_interval_seconds, created_at, updated_at)
    VALUES(?,?,?,?,?,?,'UNKNOWN',?,?,?,datetime('now'),datetime('now'))
  `).run(id, name, type, listen_host, listen_port, agent_id || null,
    rotation_mode, rotation_interval_seconds, health_check_interval_seconds);

  db.prepare(`
    INSERT INTO proxy_credentials(proxy_id, username, password_hash, created_at, updated_at)
    VALUES(?,?,?,datetime('now'),datetime('now'))
  `).run(id, username, passHash);

  logger.info(`Proxy created: ${name} port ${listen_port}`, 'PROXY', { proxy_id: id });
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(id);
  res.status(201).json(proxy);
});

router.get('/:id', requireAdmin, (req, res) => {
  const db = getDb();
  const proxy = db.prepare(`
    SELECT p.*, a.name as agent_name, pc.username as proxy_username
    FROM proxies p
    LEFT JOIN agents a ON a.id=p.agent_id
    LEFT JOIN proxy_credentials pc ON pc.proxy_id=p.id
    WHERE p.id=?
  `).get(req.params.id);
  if (!proxy) return res.status(404).json({ error: 'Proxy not found' });
  res.json(proxy);
});

router.put('/:id', requireAdmin, ...proxyRules.update, auditLog('UPDATE_PROXY', 'proxy', 'id'), async (req, res) => {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(req.params.id);
  if (!proxy) return res.status(404).json({ error: 'Proxy not found' });

  const allowed = ['name','listen_port','agent_id','rotation_mode','rotation_interval_seconds','health_check_interval_seconds'];
  const updates = {};
  for (const k of allowed) {
    if (req.body[k] !== undefined) updates[k] = req.body[k];
  }

  if (updates.listen_port && updates.listen_port !== proxy.listen_port) {
    const conflict = db.prepare('SELECT id FROM proxies WHERE listen_port=? AND id!=?').get(updates.listen_port, proxy.id);
    if (conflict) return res.status(409).json({ error: 'Port already in use' });
  }

  if (Object.keys(updates).length) {
    const setClause = Object.keys(updates).map(k => `${k}=?`).join(',');
    db.prepare(`UPDATE proxies SET ${setClause}, updated_at=datetime('now') WHERE id=?`).run(...Object.values(updates), proxy.id);
  }

  if (req.body.username || req.body.password) {
    const cred = db.prepare('SELECT * FROM proxy_credentials WHERE proxy_id=?').get(proxy.id);
    const newUser = req.body.username || cred.username;
    const newPassHash = req.body.password ? await bcrypt.hash(req.body.password, 12) : cred.password_hash;
    db.prepare(`UPDATE proxy_credentials SET username=?, password_hash=?, updated_at=datetime('now') WHERE proxy_id=?`)
      .run(newUser, newPassHash, proxy.id);
  }

  res.json(db.prepare('SELECT * FROM proxies WHERE id=?').get(proxy.id));
});

router.delete('/:id', requireAdmin, auditLog('DELETE_PROXY', 'proxy', 'id'), async (req, res) => {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(req.params.id);
  if (!proxy) return res.status(404).json({ error: 'Proxy not found' });

  if (proxy.agent_id) {
    await sendCommandToAgent(proxy.agent_id, 'STOP', { proxy_id: proxy.id });
  }

  db.prepare('DELETE FROM proxy_credentials WHERE proxy_id=?').run(proxy.id);
  db.prepare('DELETE FROM proxies WHERE id=?').run(proxy.id);

  logger.info(`Proxy deleted: ${proxy.name}`, 'PROXY', { proxy_id: proxy.id });
  res.json({ success: true });
});

router.post('/:id/start', requireAdmin, auditLog('START_PROXY', 'proxy', 'id'), async (req, res) => {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(req.params.id);
  if (!proxy) return res.status(404).json({ error: 'Proxy not found' });
  if (!proxy.agent_id) return res.status(400).json({ error: 'No agent assigned' });

  const result = await sendCommandToAgent(proxy.agent_id, 'START', { proxy_id: proxy.id });
  await updateProxyStatus(proxy.id, 'CONNECTING');
  res.json({ success: true, result });
});

router.post('/:id/stop', requireAdmin, auditLog('STOP_PROXY', 'proxy', 'id'), async (req, res) => {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(req.params.id);
  if (!proxy) return res.status(404).json({ error: 'Proxy not found' });
  if (!proxy.agent_id) return res.status(400).json({ error: 'No agent assigned' });

  const result = await sendCommandToAgent(proxy.agent_id, 'STOP', { proxy_id: proxy.id });
  await updateProxyStatus(proxy.id, 'OFFLINE');
  res.json({ success: true, result });
});

router.post('/:id/restart', requireAdmin, auditLog('RESTART_PROXY', 'proxy', 'id'), async (req, res) => {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(req.params.id);
  if (!proxy) return res.status(404).json({ error: 'Proxy not found' });
  if (!proxy.agent_id) return res.status(400).json({ error: 'No agent assigned' });

  const result = await sendCommandToAgent(proxy.agent_id, 'RESTART', { proxy_id: proxy.id });
  await updateProxyStatus(proxy.id, 'CONNECTING');
  res.json({ success: true, result });
});

router.post('/:id/rotate', requireAdmin, auditLog('ROTATE_PROXY', 'proxy', 'id'), async (req, res) => {
  const proxy = getDb().prepare('SELECT * FROM proxies WHERE id=?').get(req.params.id);
  if (!proxy) return res.status(404).json({ error: 'Proxy not found' });

  const result = await rotateProxy(proxy.id, 'MANUAL');
  res.json(result);
});

router.post('/:id/test', requireAdmin, async (req, res) => {
  const db = getDb();
  const proxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(req.params.id);
  if (!proxy) return res.status(404).json({ error: 'Proxy not found' });

  const cred = db.prepare('SELECT * FROM proxy_credentials WHERE proxy_id=?').get(proxy.id);
  if (!cred) return res.status(400).json({ error: 'No credentials found' });

  proxy.agent_id_ref = proxy.agent_id;
  const result = await fullHealthCheck({ ...proxy, password_plain: null });
  res.json(result);
});

module.exports = router;
