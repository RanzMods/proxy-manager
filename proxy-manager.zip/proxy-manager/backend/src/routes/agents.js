'use strict';

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { requireAdmin, requireAgent, auditLog } = require('../middleware/auth');
const { agentRules } = require('../middleware/validator');
const { agentLimiter } = require('../middleware/rateLimiter');
const { getDb } = require('../utils/db');
const { generateId, generateToken, dataAge } = require('../utils/helpers');
const { hashAgentToken } = require('../services/auth');
const { processHeartbeat } = require('../services/agentManager');
const { sendCommandToAgent } = require('../services/rotationManager');
const { finalizeRotation } = require('../services/rotationManager');
const { updateAgentStatus } = require('../services/statusEngine');
const logger = require('../utils/logger');

router.get('/', requireAdmin, (req, res) => {
  const db = getDb();
  const agents = db.prepare(`
    SELECT a.*,
      (SELECT COUNT(*) FROM proxies WHERE agent_id=a.id) as proxy_count
    FROM agents a
    ORDER BY a.created_at ASC
  `).all();
  res.json(agents.map(a => ({ ...a, data_age_seconds: dataAge(a.last_heartbeat) })));
});

router.get('/:id', requireAdmin, (req, res) => {
  const db = getDb();
  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  res.json({ ...agent, data_age_seconds: dataAge(agent.last_heartbeat) });
});

router.post('/pairing-token', requireAdmin, (req, res) => {
  const db = getDb();
  const token = generateToken(32);
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
  db.prepare(`
    INSERT INTO pairing_tokens(token, used, created_at, expires_at) VALUES(?,0,datetime('now'),?)
  `).run(token, expiresAt);
  logger.info('Pairing token generated', 'AGENT', { ip: req.ip });
  res.json({ token, expires_at: expiresAt, expires_in_seconds: 900 });
});

router.post('/register', agentLimiter, ...agentRules.register, async (req, res) => {
  const db = getDb();
  const { pairing_token, agent_name, device_model, android_version, termux_version, architecture } = req.body;

  const pToken = db.prepare('SELECT * FROM pairing_tokens WHERE token=? AND used=0').get(pairing_token);
  if (!pToken) return res.status(401).json({ error: 'Invalid or expired pairing token' });
  if (new Date(pToken.expires_at) < new Date()) {
    db.prepare('DELETE FROM pairing_tokens WHERE id=?').run(pToken.id);
    return res.status(401).json({ error: 'Pairing token expired' });
  }

  const agentId = generateId();
  const rawToken = generateToken(48);
  const tokenHash = hashAgentToken(rawToken);
  const tokenPrefix = rawToken.slice(0, 8);

  db.prepare(`
    INSERT INTO agents(id, name, device_model, android_version, termux_version, architecture,
      status, consecutive_failures, reconnect_supported, created_at, updated_at)
    VALUES(?,?,?,?,?,?,'CONNECTING',0,0,datetime('now'),datetime('now'))
  `).run(agentId, agent_name, device_model || null, android_version || null, termux_version || null, architecture || null);

  db.prepare(`
    INSERT INTO agent_tokens(agent_id, token_hash, token_prefix, revoked, created_at)
    VALUES(?,?,?,0,datetime('now'))
  `).run(agentId, tokenHash, tokenPrefix);

  db.prepare('UPDATE pairing_tokens SET used=1 WHERE id=?').run(pToken.id);

  logger.info(`Agent registered: ${agent_name} (${agentId})`, 'AGENT');

  res.status(201).json({
    agent_id: agentId,
    agent_token: rawToken,
    vps_api_url: process.env.VPS_API_URL || 'http://localhost:3001',
  });
});

router.post('/heartbeat', agentLimiter, requireAgent, async (req, res) => {
  const result = await processHeartbeat(req.agentId, req.body);
  res.json(result || { received: true });
});

router.get('/command/poll', agentLimiter, requireAgent, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const { addClient } = require('../services/sseManager');

  const wrappedRes = {
    write: (data) => {
      try {
        const parsed = JSON.parse(data.replace('data: ', '').trim());
        if (parsed.agentId === req.agentId || parsed.agentId === undefined) {
          res.write(data);
        }
      } catch {
        res.write(data);
      }
    },
    on: (event, cb) => res.on(event, cb),
  };

  addClient(wrappedRes);
  res.write(`data: ${JSON.stringify({ type: 'CONNECTED', timestamp: new Date().toISOString() })}\n\n`);
});

router.post('/report', agentLimiter, requireAgent, async (req, res) => {
  const db = getDb();
  const { event_type, proxy_id, old_ip, new_ip, result, error_message } = req.body;

  if (event_type === 'ROTATION_COMPLETE') {
    await finalizeRotation(proxy_id, req.agentId, new_ip, old_ip, 'AGENT');
  }

  if (event_type === 'IP_CHANGE') {
    db.prepare(`
      INSERT INTO ip_history(agent_id, proxy_id, old_ip, new_ip, method, result, verification_status, created_at)
      VALUES(?,?,?,?,'AGENT_REPORT',?,?,datetime('now'))
    `).run(req.agentId, proxy_id || null, old_ip, new_ip, result || 'IP_CHANGED', 'UNVERIFIED');
  }

  res.json({ received: true });
});

router.post('/:id/ping', requireAdmin, async (req, res) => {
  const db = getDb();
  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  const result = await sendCommandToAgent(agent.id, 'PING');
  res.json(result);
});

router.post('/:id/restart', requireAdmin, auditLog('RESTART_AGENT', 'agent', 'id'), async (req, res) => {
  const db = getDb();
  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  const result = await sendCommandToAgent(agent.id, 'RESTART');
  res.json(result);
});

router.post('/:id/reconnect', requireAdmin, auditLog('RECONNECT_AGENT', 'agent', 'id'), async (req, res) => {
  const db = getDb();
  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  const result = await sendCommandToAgent(agent.id, 'RECONNECT');
  res.json(result);
});

router.delete('/:id', requireAdmin, auditLog('DELETE_AGENT', 'agent', 'id'), async (req, res) => {
  const db = getDb();
  const agent = db.prepare('SELECT * FROM agents WHERE id=?').get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });

  db.prepare('UPDATE agent_tokens SET revoked=1 WHERE agent_id=?').run(agent.id);
  db.prepare('UPDATE proxies SET agent_id=NULL WHERE agent_id=?').run(agent.id);
  db.prepare('DELETE FROM agents WHERE id=?').run(agent.id);

  logger.info(`Agent deleted: ${agent.name}`, 'AGENT');
  res.json({ success: true });
});

module.exports = router;
