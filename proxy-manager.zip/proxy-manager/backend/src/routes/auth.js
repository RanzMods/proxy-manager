'use strict';

const express = require('express');
const router = express.Router();
const { authenticateAdmin, signToken, createAdminUser } = require('../services/auth');
const { requireAdmin, auditLog } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/rateLimiter');
const { getDb } = require('../utils/db');
const logger = require('../utils/logger');

router.post('/login', loginLimiter, async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Username and password required' });

  const user = await authenticateAdmin(username, password);
  if (!user) {
    logger.warn(`Failed login attempt: ${username}`, 'AUTH', { ip: req.ip });
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = signToken({ id: user.id, username: user.username, role: user.role });
  res.cookie('admin_token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 8 * 60 * 60 * 1000,
  });

  logger.info(`Admin login: ${username}`, 'AUTH', { ip: req.ip });
  res.json({ success: true, user: { username: user.username, role: user.role } });
});

router.post('/logout', requireAdmin, (req, res) => {
  res.clearCookie('admin_token');
  logger.info(`Admin logout: ${req.admin.username}`, 'AUTH', { ip: req.ip });
  res.json({ success: true });
});

router.get('/me', requireAdmin, (req, res) => {
  res.json({ username: req.admin.username, role: req.admin.role });
});

router.post('/change-password', requireAdmin, async (req, res) => {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password) return res.status(400).json({ error: 'Both passwords required' });
  if (new_password.length < 8) return res.status(400).json({ error: 'New password min 8 chars' });

  const { authenticateAdmin: auth, hashPassword } = require('../services/auth');
  const user = await auth(req.admin.username, current_password);
  if (!user) return res.status(401).json({ error: 'Current password incorrect' });

  const hash = await hashPassword(new_password);
  const db = getDb();
  db.prepare("UPDATE users SET password_hash=?, updated_at=datetime('now') WHERE username=?").run(hash, req.admin.username);

  logger.info(`Password changed: ${req.admin.username}`, 'AUTH', { ip: req.ip });
  res.json({ success: true });
});

module.exports = router;
