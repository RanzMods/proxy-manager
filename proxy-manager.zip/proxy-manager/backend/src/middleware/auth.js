'use strict';

const { verifyToken, authenticateAgentToken } = require('../services/auth');
const logger = require('../utils/logger');
const { getDb } = require('../utils/db');

function requireAdmin(req, res, next) {
  try {
    const token = req.cookies?.admin_token ||
      (req.headers.authorization?.startsWith('Bearer ') &&
        req.headers.authorization.slice(7));
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    const payload = verifyToken(token);
    req.admin = payload;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function requireAgent(req, res, next) {
  try {
    const header = req.headers['x-agent-token'];
    if (!header) return res.status(401).json({ error: 'Agent token required' });
    const agentRow = authenticateAgentToken(header);
    if (!agentRow) return res.status(401).json({ error: 'Invalid agent token' });
    req.agentId = agentRow.agent_id;
    req.agentRow = agentRow;
    next();
  } catch {
    return res.status(401).json({ error: 'Agent authentication failed' });
  }
}

function auditLog(action, targetType, targetId) {
  return (req, res, next) => {
    const oldSend = res.json.bind(res);
    res.json = (body) => {
      try {
        const db = getDb();
        db.prepare(`
          INSERT INTO audit_logs(admin_username, action, target_type, target_id, result, ip_address, created_at)
          VALUES(?,?,?,?,?,?,datetime('now'))
        `).run(
          req.admin?.username || 'system',
          action,
          targetType,
          targetId ? (typeof targetId === 'function' ? targetId(req) : req.params[targetId]) : null,
          res.statusCode < 400 ? 'SUCCESS' : 'FAILURE',
          req.ip
        );
      } catch (_) {}
      return oldSend(body);
    };
    next();
  };
}

module.exports = { requireAdmin, requireAgent, auditLog };
