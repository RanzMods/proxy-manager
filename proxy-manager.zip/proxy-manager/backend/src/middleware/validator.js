'use strict';

const { body, param, validationResult } = require('express-validator');

function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: 'Validation failed', details: errors.array() });
  }
  next();
}

const proxyRules = {
  create: [
    body('name').trim().isLength({ min: 1, max: 64 }).withMessage('Name 1-64 chars'),
    body('type').isIn(['SOCKS5', 'HTTP']).withMessage('Type must be SOCKS5 or HTTP'),
    body('listen_port').isInt({ min: 1024, max: 65535 }).withMessage('Port 1024-65535'),
    body('username').trim().isLength({ min: 1, max: 64 }).withMessage('Username required'),
    body('password').isLength({ min: 8 }).withMessage('Password min 8 chars'),
    body('rotation_mode').optional().isIn(['DISABLED','MANUAL','INTERVAL','ON_IP_CHANGE','AUTO']),
    body('rotation_interval_seconds').optional().isInt({ min: 60 }),
    body('health_check_interval_seconds').optional().isInt({ min: 10 }),
    validate,
  ],
  update: [
    body('name').optional().trim().isLength({ min: 1, max: 64 }),
    body('listen_port').optional().isInt({ min: 1024, max: 65535 }),
    body('username').optional().trim().isLength({ min: 1, max: 64 }),
    body('password').optional().isLength({ min: 8 }),
    body('rotation_mode').optional().isIn(['DISABLED','MANUAL','INTERVAL','ON_IP_CHANGE','AUTO']),
    body('rotation_interval_seconds').optional().isInt({ min: 60 }),
    body('health_check_interval_seconds').optional().isInt({ min: 10 }),
    validate,
  ],
};

const agentRules = {
  register: [
    body('pairing_token').notEmpty().withMessage('Pairing token required'),
    body('agent_name').trim().isLength({ min: 1, max: 64 }).withMessage('Agent name 1-64 chars'),
    body('device_model').optional().trim().isLength({ max: 128 }),
    body('android_version').optional().trim().isLength({ max: 32 }),
    body('termux_version').optional().trim().isLength({ max: 32 }),
    body('architecture').optional().trim().isLength({ max: 32 }),
    validate,
  ],
};

module.exports = { validate, proxyRules, agentRules };
