#!/usr/bin/env python3
"""
Public IP Detector for Termux Agent.
Queries multiple providers, detects conflicts, and validates format.
"""

import urllib.request
import json
import re

IP_PROVIDERS = [
    {"url": "https://api.ipify.org?format=json", "field": "ip"},
    {"url": "https://api4.my-ip.io/ip.json", "field": "ip"},
    {"url": "https://ipapi.co/json/", "field": "ip"},
]

IPV4_PATTERN = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")

def fetch_ip(provider: dict, timeout=5) -> str:
    req = urllib.request.Request(provider["url"], headers={"User-Agent": "Termux-Proxy-Agent/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read().decode("utf-8")
        try:
            parsed = json.loads(data)
            return parsed.get(provider.get("field", "ip"), "").strip()
        except Exception:
            return data.strip()

def detect_public_ip() -> dict:
    results = []
    for prov in IP_PROVIDERS:
        try:
            ip = fetch_ip(prov)
            if ip and IPV4_PATTERN.match(ip):
                results.append((ip, prov["url"]))
                if len(results) >= 2:
                    break
        except Exception:
            continue

    if not results:
        return {"ip": None, "status": "FAILED", "provider": None}

    if len(results) >= 2 and results[0][0] != results[1][0]:
        return {
            "ip": None,
            "status": "IP_CONFLICT",
            "candidates": [r[0] for r in results],
            "provider": results[0][1],
        }

    return {
        "ip": results[0][0],
        "status": "OK",
        "provider": results[0][1],
    }
