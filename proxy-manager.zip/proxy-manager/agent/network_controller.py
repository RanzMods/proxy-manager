#!/usr/bin/env python3
"""
Termux Network Controller
Supports Cellular (4G/5G), WiFi, USB Modem, and Linux NetworkManager.
Allows user preference selection: Cellular (SIM) vs WiFi.
"""

import subprocess
import time
import shutil
import os

def get_active_network_type() -> str:
    """Detect whether active internet route is WiFi, Cellular, or Ethernet"""
    try:
        res = subprocess.run(["ip", "route", "get", "1.1.1.1"], capture_output=True, text=True, timeout=2)
        if res.returncode == 0:
            out = res.stdout.lower()
            if "wlan" in out:
                return "wifi"
            elif any(x in out for x in ["rmnet", "ccmni", "pdp", "wwan", "radio", "lte"]):
                return "cellular"
            elif "eth" in out:
                return "ethernet"
    except Exception:
        pass

    # Check sysfs for wlan state
    for iface in ["wlan0", "wlan1"]:
        operstate_path = f"/sys/class/net/{iface}/operstate"
        if os.path.exists(operstate_path):
            try:
                with open(operstate_path, "r") as f:
                    if f.read().strip() == "up":
                        return "wifi"
            except Exception:
                pass

    return "cellular"

class BaseNetworkAdapter:
    def reconnect(self, mode="auto") -> bool:
        raise NotImplementedError

    def is_supported(self) -> bool:
        return False

class AndroidRootAdapter(BaseNetworkAdapter):
    """Reconnect mobile data or WiFi via root shell on Android"""
    def is_supported(self) -> bool:
        is_android = os.path.exists("/data/data/com.termux") or os.path.exists("/system/build.prop") or shutil.which("getprop") is not None
        return is_android and shutil.which("su") is not None

    def reconnect(self, mode="auto") -> bool:
        target_mode = get_active_network_type() if mode == "auto" else mode

        # If WiFi is preferred/active
        if target_mode == "wifi":
            try:
                cmd = "su -c 'cmd wifi set-wifi-enabled disabled 2>/dev/null || svc wifi disable && sleep 3 && cmd wifi set-wifi-enabled enabled 2>/dev/null || svc wifi enable'"
                res = subprocess.run(cmd, shell=True, timeout=12)
                if res.returncode == 0:
                    time.sleep(5)
                    return True
            except Exception:
                pass

        # Primary cellular reconnect: svc data
        try:
            cmd = "su -c 'svc data disable && sleep 3 && svc data enable'"
            res = subprocess.run(cmd, shell=True, timeout=12)
            if res.returncode == 0:
                time.sleep(4)
                return True
        except Exception:
            pass

        # Fallback cellular reconnect: Airplane mode toggle
        try:
            cmd = "su -c 'cmd connectivity airplane-mode enable 2>/dev/null || settings put global airplane_mode_on 1 && am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true'"
            subprocess.run(cmd, shell=True, timeout=10)
            time.sleep(3)
            cmd = "su -c 'cmd connectivity airplane-mode disable 2>/dev/null || settings put global airplane_mode_on 0 && am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false'"
            subprocess.run(cmd, shell=True, timeout=10)
            time.sleep(5)
            return True
        except Exception:
            return False

class TermuxApiAdapter(BaseNetworkAdapter):
    """Reconnect via termux-telephony or termux-wifi if accessible"""
    def is_supported(self) -> bool:
        return shutil.which("termux-wifi-enable") is not None or shutil.which("termux-telephony-device-info") is not None

    def reconnect(self, mode="auto") -> bool:
        target_mode = get_active_network_type() if mode == "auto" else mode
        if target_mode == "wifi" and shutil.which("termux-wifi-enable"):
            try:
                subprocess.run(["termux-wifi-enable", "false"], timeout=5)
                time.sleep(3)
                subprocess.run(["termux-wifi-enable", "true"], timeout=5)
                time.sleep(5)
                return True
            except Exception:
                return False
        return False

class LinuxNetworkManagerAdapter(BaseNetworkAdapter):
    """Linux nmcli adapter for USB dongles/modems/WiFi"""
    def is_supported(self) -> bool:
        return shutil.which("nmcli") is not None

    def reconnect(self, mode="auto") -> bool:
        try:
            subprocess.run(["nmcli", "networking", "off"], check=True, timeout=10)
            time.sleep(2)
            subprocess.run(["nmcli", "networking", "on"], check=True, timeout=10)
            time.sleep(5)
            return True
        except Exception:
            return False

class NetworkController:
    def __init__(self, preferred_network="auto"):
        self.preferred_network = preferred_network  # "auto", "cellular", or "wifi"
        self.adapters = [
            AndroidRootAdapter(),
            LinuxNetworkManagerAdapter(),
            TermuxApiAdapter(),
        ]
        self.active_adapter = None
        for a in self.adapters:
            if a.is_supported():
                self.active_adapter = a
                break

    def get_network_type(self) -> str:
        if self.preferred_network in ("cellular", "wifi"):
            detected = get_active_network_type()
            # If detected matches preferred, return detected; otherwise return detected
            return detected
        return get_active_network_type()

    def can_reconnect(self) -> bool:
        return self.active_adapter is not None and self.active_adapter.is_supported()

    def reconnect(self) -> bool:
        if not self.can_reconnect():
            return False
        return self.active_adapter.reconnect(mode=self.preferred_network)
