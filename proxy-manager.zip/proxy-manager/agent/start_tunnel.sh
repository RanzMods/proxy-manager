#!/bin/bash
# Robust Reverse Tunnel Manager for Termux -> VPS Relay (Mode B)
# Auto-reconnects and ensures persistent connectivity across mobile network flaps.

VPS_HOST="${1}"
VPS_SSH_PORT="${2:-22}"
VPS_USER="${3:-root}"
VPS_PROXY_PORT="${4:-10001}"
LOCAL_SOCKS_PORT="${5:-10001}"
KEY_PATH="${6:-$HOME/.ssh/id_rsa}"

if [ -z "$VPS_HOST" ]; then
  echo "Usage: ./start_tunnel.sh <VPS_HOST> [VPS_SSH_PORT] [VPS_USER] [VPS_PROXY_PORT] [LOCAL_SOCKS_PORT] [KEY_PATH]"
  exit 1
fi

# Ensure SSH key exists
if [ ! -f "$KEY_PATH" ]; then
  mkdir -p "$(dirname "$KEY_PATH")"
  ssh-keygen -t ed25519 -N "" -f "$KEY_PATH" 2>/dev/null || ssh-keygen -t rsa -b 2048 -N "" -f "$KEY_PATH" 2>/dev/null
fi

# Clean existing tunnel on same remote port
pkill -f "ssh.*-R.*:${VPS_PROXY_PORT}:" 2>/dev/null || true

echo "[Tunnel] Starting Reverse Tunnel..."
echo "         VPS Relay:  ${VPS_HOST}:${VPS_PROXY_PORT}"
echo "         Local SOCKS: 127.0.0.1:${LOCAL_SOCKS_PORT}"

SSH_OPTS="-o ServerAliveInterval=10 \
          -o ServerAliveCountMax=3 \
          -o ExitOnForwardFailure=yes \
          -o StrictHostKeyChecking=no \
          -o UserKnownHostsFile=/dev/null \
          -o ConnectTimeout=12 \
          -o TCPKeepAlive=yes"

if command -v autossh >/dev/null 2>&1; then
  export AUTOSSH_GATETIME=0
  export AUTOSSH_POLL=15
  autossh -M 0 -f -N \
    $SSH_OPTS \
    -i "$KEY_PATH" \
    -p "$VPS_SSH_PORT" \
    -R "0.0.0.0:${VPS_PROXY_PORT}:127.0.0.1:${LOCAL_SOCKS_PORT}" \
    "${VPS_USER}@${VPS_HOST}" 2>/dev/null
else
  # Background resilient loop
  nohup bash -c "
    while true; do
      ssh -N $SSH_OPTS \
        -i '$KEY_PATH' \
        -p '$VPS_SSH_PORT' \
        -R '0.0.0.0:${VPS_PROXY_PORT}:127.0.0.1:${LOCAL_SOCKS_PORT}' \
        '${VPS_USER}@${VPS_HOST}' 2>&1
      sleep 3
    done
  " >/dev/null 2>&1 &
fi

echo "[Tunnel] Reverse tunnel is active in background."
