#!/usr/bin/env python3
"""
Lightweight Pure Python SOCKS5 Server with Username/Password Authentication,
Robust Error Handling, Concurrency Protection, and Accurate Real-Time Traffic Accounting.
"""

import socket
import select
import sys
import struct
import threading
import time

MAX_CONCURRENT_CLIENTS = 256

class Socks5Server:
    def __init__(self, port=10001, username=None, password=None):
        self.port = port
        self.username = username
        self.password = password
        self.bytes_in = 0   # Download: remote -> client
        self.bytes_out = 0  # Upload: client -> remote
        self.active_connections = 0
        self.lock = threading.Lock()
        self.semaphore = threading.Semaphore(MAX_CONCURRENT_CLIENTS)
        self.running = False
        self.server_sock = None
        self.server_thread = None

    def get_stats(self):
        with self.lock:
            return {
                "bytes_in": self.bytes_in,
                "bytes_out": self.bytes_out,
                "total_bytes": self.bytes_in + self.bytes_out,
                "active_connections": self.active_connections,
            }

    def handle_client(self, client_sock):
        acquired = self.semaphore.acquire(blocking=False)
        if not acquired:
            try:
                client_sock.close()
            except Exception:
                pass
            return

        with self.lock:
            self.active_connections += 1

        remote_sock = None
        try:
            client_sock.settimeout(12.0)
            try:
                client_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except Exception:
                pass

            # SOCKS greeting
            head = client_sock.recv(2)
            if not head or len(head) < 2 or head[0] != 0x05:
                return
            nmethods = head[1]
            methods = client_sock.recv(nmethods)
            if not methods or len(methods) < nmethods:
                return

            # Authenticate if username/password set
            if self.username and self.password:
                if 0x02 not in methods:
                    client_sock.sendall(b"\x05\xff")
                    return
                client_sock.sendall(b"\x05\x02")

                # Read auth sub-negotiation
                v = client_sock.recv(1)
                if not v or v[0] != 0x01:
                    return
                ulen_raw = client_sock.recv(1)
                if not ulen_raw:
                    return
                ulen = ulen_raw[0]
                uname = client_sock.recv(ulen).decode("utf-8", "ignore")
                plen_raw = client_sock.recv(1)
                if not plen_raw:
                    return
                plen = plen_raw[0]
                passwd = client_sock.recv(plen).decode("utf-8", "ignore")

                if uname != self.username or passwd != self.password:
                    client_sock.sendall(b"\x01\x01")
                    return
                client_sock.sendall(b"\x01\x00")
            else:
                client_sock.sendall(b"\x05\x00")

            # Read SOCKS request
            req = client_sock.recv(4)
            if not req or len(req) < 4 or req[0] != 0x05 or req[1] != 0x01:  # Only CONNECT is supported
                return

            atyp = req[3]
            dest_addr = None
            if atyp == 0x01:  # IPv4
                raw_ip = client_sock.recv(4)
                if len(raw_ip) == 4:
                    dest_addr = socket.inet_ntoa(raw_ip)
            elif atyp == 0x03:  # Domain Name
                alen_raw = client_sock.recv(1)
                if alen_raw:
                    alen = alen_raw[0]
                    domain_bytes = client_sock.recv(alen)
                    if len(domain_bytes) == alen:
                        dest_addr = domain_bytes.decode("utf-8", "ignore")
            elif atyp == 0x04:  # IPv6
                raw_ip6 = client_sock.recv(16)
                if len(raw_ip6) == 16:
                    dest_addr = socket.inet_ntop(socket.AF_INET6, raw_ip6)

            if not dest_addr:
                return

            port_raw = client_sock.recv(2)
            if len(port_raw) < 2:
                return
            dest_port = struct.unpack(">H", port_raw)[0]

            # Connect outbound using getaddrinfo for high reliability (IPv4 & IPv6)
            try:
                addrs = socket.getaddrinfo(dest_addr, dest_port, socket.AF_UNSPEC, socket.SOCK_STREAM)
            except Exception:
                client_sock.sendall(b"\x05\x04\x00\x01\x00\x00\x00\x00\x00\x00")  # Host unreachable
                return

            connected = False
            for family, socktype, proto, canonname, sockaddr in addrs:
                try:
                    remote_sock = socket.socket(family, socktype, proto)
                    remote_sock.settimeout(10.0)
                    try:
                        remote_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    except Exception:
                        pass
                    remote_sock.connect(sockaddr)
                    connected = True
                    break
                except Exception:
                    if remote_sock:
                        try: remote_sock.close()
                        except Exception: pass
                        remote_sock = None

            if not connected or not remote_sock:
                client_sock.sendall(b"\x05\x05\x00\x01\x00\x00\x00\x00\x00\x00")  # Connection refused
                return

            # Success reply
            client_sock.sendall(b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00")

            # Bidirectional relay with byte accounting
            remote_sock.setblocking(False)
            client_sock.setblocking(False)
            sockets = [client_sock, remote_sock]

            while self.running:
                r, _, x = select.select(sockets, [], sockets, 30)
                if x:
                    break
                if not r:
                    break
                closed = False
                for s in r:
                    try:
                        data = s.recv(16384)
                    except (BlockingIOError, InterruptedError):
                        continue
                    except Exception:
                        closed = True
                        break

                    if not data:
                        closed = True
                        break

                    byte_len = len(data)
                    try:
                        if s is client_sock:
                            remote_sock.sendall(data)
                            with self.lock:
                                self.bytes_out += byte_len
                        else:
                            client_sock.sendall(data)
                            with self.lock:
                                self.bytes_in += byte_len
                    except Exception:
                        closed = True
                        break

                if closed:
                    break

        except Exception:
            pass
        finally:
            with self.lock:
                if self.active_connections > 0:
                    self.active_connections -= 1
            self.semaphore.release()
            if client_sock:
                try: client_sock.close()
                except Exception: pass
            if remote_sock:
                try: remote_sock.close()
                except Exception: pass

    def run(self):
        try:
            self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_sock.bind(("0.0.0.0", self.port))
            self.server_sock.listen(128)
            self.server_sock.settimeout(1.0)
            self.running = True
        except Exception as e:
            print(f"Failed to bind SOCKS5 server on port {self.port}: {e}")
            self.running = False
            return

        while self.running:
            try:
                client, _ = self.server_sock.accept()
                t = threading.Thread(target=self.handle_client, args=(client,), daemon=True)
                t.start()
            except socket.timeout:
                continue
            except Exception:
                break

    def start(self):
        if self.running and self.server_thread and self.server_thread.is_alive():
            return True
        self.server_thread = threading.Thread(target=self.run, daemon=True)
        self.server_thread.start()
        time.sleep(0.3)
        return self.running

    def stop(self):
        self.running = False
        if self.server_sock:
            try:
                self.server_sock.close()
            except Exception:
                pass
            self.server_sock = None
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=1.5)

    def is_alive(self):
        return self.running and self.server_thread is not None and self.server_thread.is_alive()

def run_standalone(port, user, password):
    srv = Socks5Server(port, user, password)
    srv.start()
    print(f"SOCKS5 server running on port {port}...")
    try:
        while True:
            time.sleep(2)
            stats = srv.get_stats()
            print(f"[Traffic] In: {stats['bytes_in']} B | Out: {stats['bytes_out']} B | Total: {stats['total_bytes']} B | Conns: {stats['active_connections']}")
    except KeyboardInterrupt:
        srv.stop()

if __name__ == "__main__":
    p = int(sys.argv[1]) if len(sys.argv) > 1 else 10001
    u = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] else None
    pw = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] else None
    run_standalone(p, u, pw)
