#!/usr/bin/env python3
"""
Main Termux Agent Process.
Handles pairing, self-healing watchdog, heartbeat, commands from VPS,
multi-step IP detection, and robust SOCKS5 proxy service.
"""

import sys
import os
import time
import json
import urllib.request
import urllib.error
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from network_controller import NetworkController
from ip_detector import detect_public_ip
from proxy_server import ProxyServerManager

CONFIG_FILE = os.path.expanduser("~/.proxy_agent_config.json")

class TermuxAgent:
    def __init__(self):
        self.config = self.load_config()
        self.preferred_network = self.config.get("preferred_network", "cellular")
        self.net_ctrl = NetworkController(preferred_network=self.preferred_network)
        self.proxy_mgr = ProxyServerManager(
            port=self.config.get("local_proxy_port", 10001),
            username=self.config.get("proxy_username", "proxyuser"),
            password=self.config.get("proxy_password", "proxypassword"),
        )
        self.running = False
        self.start_time = time.time()
        self.current_ip = None
        self.consecutive_errors = 0

    def load_config(self) -> dict:
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def save_config(self):
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            print(f"Error saving configuration: {e}")

    def pair(self, vps_url, pairing_token, agent_name="Termux-Device", preferred_network="cellular"):
        clean_url = vps_url.rstrip("/")
        url = f"{clean_url}/api/agents/register"
        payload = {
            "pairing_token": pairing_token,
            "agent_name": agent_name,
            "device_model": os.uname().machine,
            "architecture": os.uname().machine,
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "User-Agent": "Termux-Agent/1.0"},
        )
        try:
            with urllib.request.urlopen(req, timeout=12) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                self.config["agent_id"] = data["agent_id"]
                self.config["agent_token"] = data["agent_token"]
                self.config["vps_api_url"] = clean_url
                self.config["preferred_network"] = preferred_network
                self.net_ctrl.preferred_network = preferred_network
                self.save_config()
                print(f"Pairing successful! Network mode: {preferred_network.upper()}. Token saved to ~/.proxy_agent_config.json")
                return True
        except Exception as e:
            print(f"Pairing failed: {e}")
            return False

    def send_heartbeat(self):
        if not self.config.get("agent_token"):
            return

        # Watchdog: Ensure SOCKS5 server is running
        if not self.proxy_mgr.is_running():
            print("[Watchdog] SOCKS5 proxy was stopped. Auto-restarting...")
            self.proxy_mgr.start()

        ip_info = detect_public_ip()
        if ip_info.get("ip"):
            self.current_ip = ip_info.get("ip")

        traffic_stats = self.proxy_mgr.get_stats()
        current_net_type = self.net_ctrl.get_network_type()

        url = f"{self.config['vps_api_url']}/api/agents/heartbeat"
        payload = {
            "public_ip": self.current_ip,
            "network_type": current_net_type,
            "proxy_status": {"running": self.proxy_mgr.is_running()},
            "uptime_seconds": int(time.time() - self.start_time),
            "reconnect_supported": self.net_ctrl.can_reconnect(),
            "traffic": traffic_stats,
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "x-agent-token": self.config["agent_token"],
                "User-Agent": "Termux-Agent/1.0",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=6) as resp:
                self.consecutive_errors = 0
        except Exception:
            self.consecutive_errors += 1

    def execute_command(self, cmd_type, payload):
        print(f"[Command] Received: {cmd_type} {payload}")

        if cmd_type in ("ROTATE", "RECONNECT"):
            old_ip = self.current_ip
            self.net_ctrl.reconnect()

            # Resilient network recovery loop: wait up to 30s for internet reconnection
            new_ip = None
            for attempt in range(10):
                time.sleep(3)
                ip_info = detect_public_ip()
                if ip_info.get("status") == "OK" and ip_info.get("ip"):
                    new_ip = ip_info.get("ip")
                    self.current_ip = new_ip
                    break

            if new_ip and new_ip != old_ip:
                result = "SUCCESS"
            elif new_ip == old_ip:
                result = "IP_UNCHANGED"
            else:
                result = "IP_UNVERIFIED"

            # Resilient report sending: retry up to 5 times if network is still recovering
            report_url = f"{self.config['vps_api_url']}/api/agents/report"
            res_payload = {
                "event_type": "ROTATION_COMPLETE",
                "proxy_id": payload.get("proxy_id"),
                "old_ip": old_ip,
                "new_ip": new_ip,
                "result": result,
            }

            for report_attempt in range(5):
                try:
                    req = urllib.request.Request(
                        report_url,
                        data=json.dumps(res_payload).encode("utf-8"),
                        headers={
                            "Content-Type": "application/json",
                            "x-agent-token": self.config["agent_token"],
                        },
                    )
                    with urllib.request.urlopen(req, timeout=8) as resp:
                        break
                except Exception:
                    time.sleep(3)

        elif cmd_type == "START":
            self.proxy_mgr.start()
        elif cmd_type == "STOP":
            self.proxy_mgr.stop()
        elif cmd_type == "RESTART":
            self.proxy_mgr.restart()

    def command_listener(self):
        """Poll commands via persistent SSE with automatic exponential backoff"""
        backoff = 3
        while self.running:
            if not self.config.get("agent_token"):
                time.sleep(5)
                continue
            try:
                url = f"{self.config['vps_api_url']}/api/agents/command/poll"
                req = urllib.request.Request(
                    url,
                    headers={
                        "x-agent-token": self.config["agent_token"],
                        "User-Agent": "Termux-Agent/1.0",
                    },
                )
                with urllib.request.urlopen(req, timeout=90) as resp:
                    backoff = 3
                    for raw_line in resp:
                        if not self.running:
                            break
                        line = raw_line.decode("utf-8", "ignore").strip()
                        if line.startswith("data:"):
                            try:
                                data = json.loads(line[5:].strip())
                                if data.get("type") == "AGENT_COMMAND":
                                    self.execute_command(data.get("command"), data.get("payload", {}))
                            except Exception:
                                pass
            except Exception:
                time.sleep(backoff)
                backoff = min(backoff * 2, 30)

    def start(self):
        if not self.config.get("agent_token"):
            print("Agent not paired. Run: python3 agent.py pair <VPS_URL> <TOKEN> [DEVICE_NAME]")
            return

        self.running = True
        print("Starting SOCKS5 Proxy Service...")
        self.proxy_mgr.start()

        # Command listener thread
        listener_thread = threading.Thread(target=self.command_listener, daemon=True)
        listener_thread.start()

        print(f"Termux Agent running on port {self.proxy_mgr.port}. Entering heartbeat loop...")

        # Heartbeat loop
        while self.running:
            try:
                self.send_heartbeat()
            except Exception as e:
                pass
            time.sleep(5)

    def stop(self):
        self.running = False
        self.proxy_mgr.stop()
        print("Termux Agent stopped.")

if __name__ == "__main__":
    agent = TermuxAgent()
    if len(sys.argv) > 1 and sys.argv[1] == "pair":
        if len(sys.argv) < 4:
            print("Usage: python agent.py pair <VPS_URL> <PAIRING_TOKEN> [DEVICE_NAME] [preferred_network: cellular|wifi]")
            sys.exit(1)
        vps = sys.argv[2]
        token = sys.argv[3]
        name = sys.argv[4] if len(sys.argv) > 4 else "Termux-Device"
        preferred_net = sys.argv[5] if len(sys.argv) > 5 else "cellular"
        agent.pair(vps, token, name, preferred_net)
    else:
        try:
            print("Starting Termux Agent...")
            agent.start()
        except KeyboardInterrupt:
            agent.stop()
