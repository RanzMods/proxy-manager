#!/bin/bash
# Stop running reverse tunnels
pkill -f "autossh.*127.0.0.1" || true
pkill -f "ssh.*-R.*127.0.0.1" || true
echo "Tunnel processes stopped."
