#!/usr/bin/env python3
"""
SOCKS5 Proxy Server Manager for Termux
Manages the SOCKS5 proxy server lifecycle and provides real-time traffic monitoring.
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from socks5_server import Socks5Server

class ProxyServerManager:
    def __init__(self, port=10001, username="proxyuser", password="proxypassword"):
        self.port = port
        self.username = username
        self.password = password
        self.server = None

    def start(self) -> bool:
        if self.is_running():
            return True
        self.server = Socks5Server(self.port, self.username, self.password)
        return self.server.start()

    def stop(self):
        if self.server:
            self.server.stop()
            self.server = None

    def restart(self) -> bool:
        self.stop()
        return self.start()

    def is_running(self) -> bool:
        if not self.server:
            return False
        return self.server.is_alive()

    def get_stats(self) -> dict:
        if not self.server:
            return {"bytes_in": 0, "bytes_out": 0, "total_bytes": 0, "active_connections": 0}
        return self.server.get_stats()
