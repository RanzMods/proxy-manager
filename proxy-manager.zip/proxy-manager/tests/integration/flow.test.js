'use strict';

const test = require('node:test');
const assert = require('node:assert');
const path = require('path');
const fs = require('fs');

process.env.DB_PATH = path.join(__dirname, 'integration_test.db');
process.env.JWT_SECRET = 'test_integration_secret_jwt_32_characters';

const { getDb } = require('../../backend/src/utils/db');
const { processHeartbeat } = require('../../backend/src/services/agentManager');

test('Integration - Agent registration and heartbeat flow', async () => {
  // Init DB schema
  const db = getDb();
  const schema1 = fs.readFileSync(path.join(__dirname, '../../database/migrations/001_initial.sql'), 'utf-8');
  db.exec(schema1);
  const schema2 = fs.readFileSync(path.join(__dirname, '../../database/migrations/002_add_traffic_usage.sql'), 'utf-8');
  db.exec(schema2);

  // Insert mock agent
  const agentId = 'test-agent-001';
  db.prepare(`
    INSERT INTO agents(id, name, status, consecutive_failures, created_at, updated_at)
    VALUES(?, 'Integration Test Phone', 'CONNECTING', 0, datetime('now'), datetime('now'))
  `).run(agentId);

  // Process heartbeat with IP
  const result = await processHeartbeat(agentId, {
    public_ip: '180.244.120.10',
    network_type: 'LTE',
    uptime_seconds: 120,
    latency_ms: 45,
  });

  assert.strictEqual(result.received, true);

  // Verify updated state
  const updatedAgent = db.prepare('SELECT * FROM agents WHERE id=?').get(agentId);
  assert.strictEqual(updatedAgent.status, 'ONLINE');
  assert.strictEqual(updatedAgent.public_ip, '180.244.120.10');
  assert.strictEqual(updatedAgent.consecutive_failures, 0);

  // Heartbeat with IP change
  await processHeartbeat(agentId, {
    public_ip: '180.244.120.99',
    network_type: 'LTE',
    uptime_seconds: 125,
    latency_ms: 50,
  });

  const changedAgent = db.prepare('SELECT * FROM agents WHERE id=?').get(agentId);
  assert.strictEqual(changedAgent.public_ip, '180.244.120.99');
  assert.strictEqual(changedAgent.previous_ip, '180.244.120.10');

  // Verify IP history entry
  const history = db.prepare('SELECT * FROM ip_history WHERE agent_id=?').all(agentId);
  assert.strictEqual(history.length >= 1, true);
  assert.strictEqual(history[0].old_ip, '180.244.120.10');
  assert.strictEqual(history[0].new_ip, '180.244.120.99');
});

test.after(() => {
  if (fs.existsSync(process.env.DB_PATH)) {
    fs.unlinkSync(process.env.DB_PATH);
  }
});
