#!/usr/bin/env python3
import http.server
import threading
import json
import os
import sys

pairing_token_received = False
heartbeat_received = False
reported_net_type = None

class MockVPSHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        global pairing_token_received, heartbeat_received, reported_net_type
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length).decode("utf-8"))

        if self.path == "/api/agents/register":
            pairing_token_received = (body.get("pairing_token") == "valid_test_token")
            self.send_response(201)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({
                "agent_id": "test_paired_agent_id",
                "agent_token": "agent_token_secret_xyz",
            }).encode("utf-8"))

        elif self.path == "/api/agents/heartbeat":
            heartbeat_received = (self.headers.get("x-agent-token") == "agent_token_secret_xyz")
            reported_net_type = body.get("network_type")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"received": true}')

    def log_message(self, format, *args):
        pass

def run_test():
    server = http.server.HTTPServer(("127.0.0.1", 28080), MockVPSHandler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../agent"))
    from agent import TermuxAgent
    import agent

    test_config_path = "/tmp/test_agent_config.json"
    if os.path.exists(test_config_path):
        os.remove(test_config_path)

    agent.CONFIG_FILE = test_config_path

    # Test Cellular Mode
    ag = TermuxAgent()
    paired = ag.pair("http://127.0.0.1:28080", "valid_test_token", "Test-Cellular-Phone", "cellular")
    assert paired, "Cellular pairing should succeed"
    assert ag.config.get("preferred_network") == "cellular"
    ag.send_heartbeat()
    assert heartbeat_received, "Heartbeat should succeed"

    # Test WiFi Mode
    ag_wifi = TermuxAgent()
    paired_wifi = ag_wifi.pair("http://127.0.0.1:28080", "valid_test_token", "Test-WiFi-Phone", "wifi")
    assert paired_wifi, "WiFi pairing should succeed"
    assert ag_wifi.config.get("preferred_network") == "wifi"

    server.shutdown()
    if os.path.exists(test_config_path):
        os.remove(test_config_path)

    print("Termux Agent Cellular & WiFi pairing tests PASSED!")

if __name__ == "__main__":
    run_test()
