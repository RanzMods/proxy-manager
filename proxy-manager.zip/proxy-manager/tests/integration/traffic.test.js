'use strict';

const test = require('node:test');
const assert = require('node:assert');
const path = require('path');
const fs = require('fs');

process.env.DB_PATH = path.join(__dirname, 'traffic_test.db');
process.env.JWT_SECRET = 'traffic_test_secret_jwt_32_characters';

const { getDb } = require('../../backend/src/utils/db');
const { processHeartbeat } = require('../../backend/src/services/agentManager');

test('Traffic Usage - Accurate Real-time Tracking and Persistence', async () => {
  const db = getDb();

  // Run migrations 001 and 002
  const m1 = fs.readFileSync(path.join(__dirname, '../../database/migrations/001_initial.sql'), 'utf-8');
  db.exec(m1);
  const m2 = fs.readFileSync(path.join(__dirname, '../../database/migrations/002_add_traffic_usage.sql'), 'utf-8');
  db.exec(m2);

  const agentId = 'traffic-agent-01';
  db.prepare(`
    INSERT INTO agents(id, name, status, created_at, updated_at)
    VALUES(?, 'Traffic Phone', 'ONLINE', datetime('now'), datetime('now'))
  `).run(agentId);

  const proxyId = 'traffic-proxy-01';
  db.prepare(`
    INSERT INTO proxies(id, name, listen_port, agent_id, status, created_at, updated_at)
    VALUES(?, 'Test Proxy Traffic', 12345, ?, 'ONLINE', datetime('now'), datetime('now'))
  `).run(proxyId, agentId);

  // Send heartbeat with traffic metrics
  const trafficData = {
    bytes_in: 1048576,    // 1 MB download
    bytes_out: 524288,    // 0.5 MB upload
    total_bytes: 1572864, // 1.5 MB total
    active_connections: 3,
  };

  await processHeartbeat(agentId, {
    public_ip: '180.250.1.1',
    network_type: '5G',
    uptime_seconds: 300,
    traffic: trafficData,
  });

  // Verify Agent table updated
  const updatedAgent = db.prepare('SELECT * FROM agents WHERE id=?').get(agentId);
  assert.strictEqual(updatedAgent.bytes_in, 1048576);
  assert.strictEqual(updatedAgent.bytes_out, 524288);
  assert.strictEqual(updatedAgent.total_bytes, 1572864);

  // Verify Proxy table updated
  const updatedProxy = db.prepare('SELECT * FROM proxies WHERE id=?').get(proxyId);
  assert.strictEqual(updatedProxy.bytes_in, 1048576);
  assert.strictEqual(updatedProxy.bytes_out, 524288);
  assert.strictEqual(updatedProxy.total_bytes, 1572864);

  // Verify Traffic History table recorded
  const history = db.prepare('SELECT * FROM traffic_history WHERE agent_id=?').all(agentId);
  assert.strictEqual(history.length, 1);
  assert.strictEqual(history[0].bytes_in, 1048576);
  assert.strictEqual(history[0].bytes_out, 524288);
  assert.strictEqual(history[0].total_bytes, 1572864);
});

test.after(() => {
  if (fs.existsSync(process.env.DB_PATH)) {
    fs.unlinkSync(process.env.DB_PATH);
  }
});
