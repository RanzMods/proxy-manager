'use strict';

const test = require('node:test');
const assert = require('node:assert');
const path = require('path');
const http = require('http');

process.env.DB_PATH = path.join(__dirname, '../../database/proxy-manager.db');
process.env.JWT_SECRET = 'test_integration_secret_jwt_32_characters';
process.env.PORT = '3999';

// Require app and db
const { getDb } = require('../../backend/src/utils/db');
const { createAdminUser, signToken } = require('../../backend/src/services/auth');

let server;
const BASE_URL = 'http://127.0.0.1:3999';

test.before(async () => {
  // Ensure schema and admin user
  const db = getDb();
  try {
    await createAdminUser('testadmin', 'Password1234!');
  } catch (_) {}

  // Require express app without starting index.js scheduler
  const express = require('express');
  const cookieParser = require('cookie-parser');
  const app = express();
  app.use(express.json());
  app.use(cookieParser());

  app.use('/api/auth', require('../../backend/src/routes/auth'));
  app.use('/api/proxies', require('../../backend/src/routes/proxies'));
  app.use('/api/agents', require('../../backend/src/routes/agents'));
  app.use('/api/ip-history', require('../../backend/src/routes/ipHistory'));
  app.use('/api/logs', require('../../backend/src/routes/logs'));
  app.use('/api/status', require('../../backend/src/routes/status'));
  app.use('/api/settings', require('../../backend/src/routes/settings'));

  app.get('/api/health', (req, res) => res.json({ status: 'HEALTHY' }));

  server = http.createServer(app);
  await new Promise((resolve) => server.listen(3999, '127.0.0.1', resolve));
});

test.after(async () => {
  if (server) {
    await new Promise((resolve) => server.close(resolve));
  }
});

test('API - Health check', async () => {
  const res = await fetch(`${BASE_URL}/api/health`);
  assert.strictEqual(res.status, 200);
  const data = await res.json();
  assert.strictEqual(data.status, 'HEALTHY');
});

test('API - Auth login flow (success and fail)', async () => {
  // Fail login
  const failRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'testadmin', password: 'wrongpassword' }),
  });
  assert.strictEqual(failRes.status, 401);

  // Success login
  const successRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'testadmin', password: 'Password1234!' }),
  });
  assert.strictEqual(successRes.status, 200);
  const cookie = successRes.headers.get('set-cookie');
  assert.ok(cookie && cookie.includes('admin_token='));
});

test('API - Protected routes with JWT Token', async () => {
  const token = signToken({ id: 1, username: 'testadmin', role: 'admin' });
  const authHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  // Status overview
  const statusRes = await fetch(`${BASE_URL}/api/status`, { headers: authHeaders });
  assert.strictEqual(statusRes.status, 200);
  const statusData = await statusRes.json();
  assert.ok(statusData.proxies);
  assert.ok(statusData.agents);
  assert.ok(statusData.rotations);

  // Generate pairing token
  const pairRes = await fetch(`${BASE_URL}/api/agents/pairing-token`, {
    method: 'POST',
    headers: authHeaders,
  });
  assert.strictEqual(pairRes.status, 200);
  const pairData = await pairRes.json();
  assert.ok(pairData.token);
  assert.strictEqual(pairData.expires_in_seconds, 900);

  // Register agent using pairing token
  const regRes = await fetch(`${BASE_URL}/api/agents/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      pairing_token: pairData.token,
      agent_name: 'Test-Phone-Pixel',
      device_model: 'Pixel 7',
      android_version: '14',
    }),
  });
  assert.strictEqual(regRes.status, 201);
  const regData = await regRes.json();
  assert.ok(regData.agent_id);
  assert.ok(regData.agent_token);

  // Heartbeat using agent token
  const hbRes = await fetch(`${BASE_URL}/api/agents/heartbeat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-agent-token': regData.agent_token,
    },
    body: JSON.stringify({
      public_ip: '180.244.1.20',
      network_type: '5G',
      uptime_seconds: 50,
      latency_ms: 30,
    }),
  });
  assert.strictEqual(hbRes.status, 200);

  // Verify agent is in agents list
  const agentsRes = await fetch(`${BASE_URL}/api/agents`, { headers: authHeaders });
  assert.strictEqual(agentsRes.status, 200);
  const agentsList = await agentsRes.json();
  const found = agentsList.find(a => a.id === regData.agent_id);
  assert.ok(found);
  assert.strictEqual(found.status, 'ONLINE');
  assert.strictEqual(found.public_ip, '180.244.1.20');

  // Create proxy assigned to this agent
  const testPort = 20000 + Math.floor(Math.random() * 20000);
  const testName = `Proxy-Test-${Date.now()}`;
  const createProxyRes = await fetch(`${BASE_URL}/api/proxies`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      name: testName,
      type: 'SOCKS5',
      listen_port: testPort,
      agent_id: regData.agent_id,
      username: 'user01',
      password: 'password01Strong',
    }),
  });
  assert.strictEqual(createProxyRes.status, 201);
  const proxyData = await createProxyRes.json();
  assert.strictEqual(proxyData.listen_port, testPort);

  // List proxies
  const proxiesListRes = await fetch(`${BASE_URL}/api/proxies`, { headers: authHeaders });
  assert.strictEqual(proxiesListRes.status, 200);
  const proxiesList = await proxiesListRes.json();
  assert.ok(proxiesList.some(p => p.id === proxyData.id));

  // Clean up proxy
  const delRes = await fetch(`${BASE_URL}/api/proxies/${proxyData.id}`, {
    method: 'DELETE',
    headers: authHeaders,
  });
  assert.strictEqual(delRes.status, 200);
});
