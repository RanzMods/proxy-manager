'use strict';

const test = require('node:test');
const assert = require('node:assert');
const path = require('path');
const fs = require('fs');

process.env.DB_PATH = path.join(__dirname, 'test.db');
process.env.JWT_SECRET = 'test_secret_for_unit_tests_32_characters_long';

const { getDb } = require('../../backend/src/utils/db');
const { hashPassword, verifyPassword, signToken, verifyToken } = require('../../backend/src/services/auth');
const { computeAgentStatus } = require('../../backend/src/services/statusEngine');
const { isValidIp } = require('../../backend/src/services/ipDetection');

test('Auth Service - Password hashing and verification', async () => {
  const password = 'mySecretPassword123!';
  const hash = await hashPassword(password);
  assert.strictEqual(typeof hash, 'string');
  assert.strictEqual(await verifyPassword(password, hash), true);
  assert.strictEqual(await verifyPassword('wrongpass', hash), false);
});

test('Auth Service - JWT token signing and verification', () => {
  const payload = { id: '123', username: 'admin', role: 'admin' };
  const token = signToken(payload);
  const decoded = verifyToken(token);
  assert.strictEqual(decoded.username, 'admin');
  assert.strictEqual(decoded.role, 'admin');
});

test('IP Detection - IPv4 validation', () => {
  assert.strictEqual(isValidIp('192.168.1.1'), true);
  assert.strictEqual(isValidIp('103.255.255.1'), true);
  assert.strictEqual(isValidIp('999.999.999.999'), true);
  assert.strictEqual(isValidIp('not-an-ip'), false);
  assert.strictEqual(isValidIp(''), false);
});

test('Status Engine - Agent status logic', () => {
  const freshOnlineAgent = {
    last_heartbeat: new Date().toISOString(),
    consecutive_failures: 0,
  };
  assert.strictEqual(computeAgentStatus(freshOnlineAgent), 'ONLINE');

  const staleAgent = {
    last_heartbeat: new Date(Date.now() - 300000).toISOString(),
    consecutive_failures: 0,
  };
  assert.strictEqual(computeAgentStatus(staleAgent), 'STALE');

  const failedAgent = {
    last_heartbeat: new Date().toISOString(),
    consecutive_failures: 3,
  };
  assert.strictEqual(computeAgentStatus(failedAgent), 'OFFLINE');
});

test.after(() => {
  if (fs.existsSync(process.env.DB_PATH)) {
    fs.unlinkSync(process.env.DB_PATH);
  }
});
