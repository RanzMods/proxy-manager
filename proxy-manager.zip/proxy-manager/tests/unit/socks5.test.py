#!/usr/bin/env python3
import socket
import struct
import time
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../agent"))
from socks5_server import Socks5Server

def test_socks5():
    port = 25055
    user = "testuser"
    password = "secretpassword"

    server = Socks5Server(port, user, password)
    assert server.start()
    time.sleep(0.5)

    try:
        # Initial stats
        stats0 = server.get_stats()
        assert stats0["bytes_in"] == 0
        assert stats0["bytes_out"] == 0
        assert stats0["total_bytes"] == 0
        assert stats0["active_connections"] == 0

        # Test 1: SOCKS5 greeting + Auth Success
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect(("127.0.0.1", port))

        # Greeting: SOCKS5, 1 method: username/password (0x02)
        s.sendall(b"\x05\x01\x02")
        resp = s.recv(2)
        assert resp == b"\x05\x02", f"Expected [0x05, 0x02], got {resp}"

        # Send credentials
        u = user.encode()
        p = password.encode()
        req = bytes([0x01, len(u)]) + u + bytes([len(p)]) + p
        s.sendall(req)
        auth_resp = s.recv(2)
        assert auth_resp == b"\x01\x00", f"Expected [0x01, 0x00] success, got {auth_resp}"
        s.close()

        # Test 2: SOCKS5 greeting + Auth Fail
        s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s2.settimeout(5)
        s2.connect(("127.0.0.1", port))
        s2.sendall(b"\x05\x01\x02")
        s2.recv(2)
        bad_req = bytes([0x01, 4]) + b"user" + bytes([8]) + b"wrongpwd"
        s2.sendall(bad_req)
        auth_resp2 = s2.recv(2)
        assert auth_resp2 == b"\x01\x01", f"Expected [0x01, 0x01] failure, got {auth_resp2}"
        s2.close()

        print("SOCKS5 Server tests with stats tracking PASSED successfully!")
    finally:
        server.stop()

if __name__ == "__main__":
    test_socks5()
