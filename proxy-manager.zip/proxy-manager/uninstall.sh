#!/usr/bin/env bash
# Uninstall script for Mobile Proxy Manager

set -e

if [ "$EUID" -ne 0 ]; then
  echo "[-] Please run as root (or with sudo)."
  exit 1
fi

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "============================================================"
echo "    Mobile Proxy Manager - Uninstaller"
echo "============================================================"
FORCE="$1"

if [[ "$FORCE" != "-y" ]]; then
  read -p "Are you ABSOLUTELY sure you want to uninstall and remove all data? (y/N): " CONFIRM
  if [[ "$CONFIRM" != "y" && "$CONFIRM" != "Y" ]]; then
    echo "Uninstallation aborted."
    exit 0
  fi
fi

echo "[*] Stopping and disabling systemd service..."
if command -v systemctl >/dev/null 2>&1; then
  systemctl stop proxy-manager-backend.service 2>/dev/null || true
  systemctl disable proxy-manager-backend.service 2>/dev/null || true
  rm -f /etc/systemd/system/proxy-manager-backend.service
  systemctl daemon-reload 2>/dev/null || true
fi

echo "[*] Removing Nginx configuration..."
rm -f /etc/nginx/sites-enabled/proxy-manager.conf
rm -f /etc/nginx/sites-available/proxy-manager.conf
rm -f /etc/nginx/conf.d/proxy-manager.conf
if command -v systemctl >/dev/null 2>&1; then
  systemctl reload nginx 2>/dev/null || true
fi

echo "[*] Removing CLI symlink..."
rm -f /usr/local/bin/proxy-manager

if [[ "$FORCE" != "-y" ]]; then
  read -p "Delete database, logs, and config files in $DIR? (y/N): " DEL_DATA
  if [[ "$DEL_DATA" == "y" || "$DEL_DATA" == "Y" ]]; then
    rm -rf "$DIR/database" "$DIR/logs" "$DIR/backups" "$DIR/.env"
    echo "[*] Data deleted."
  fi
fi

echo "============================================================"
echo "Uninstallation complete."
echo "============================================================"
