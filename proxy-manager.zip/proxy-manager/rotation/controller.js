'use strict';

/**
 * Standalone IP rotation controller utility
 */
const { rotateProxy, finalizeRotation, autoRotationTick } = require('../backend/src/services/rotationManager');
const { getDb } = require('../backend/src/utils/db');

async function triggerRotation(proxyId, reason = 'MANUAL') {
  return rotateProxy(proxyId, reason);
}

module.exports = { triggerRotation, finalizeRotation, autoRotationTick };

if (require.main === module) {
  const proxyId = process.argv[2];
  if (!proxyId) {
    console.log('Usage: node rotation/controller.js <proxy_id>');
    process.exit(1);
  }
  triggerRotation(proxyId).then(res => {
    console.log('Rotation result:', res);
    process.exit(0);
  }).catch(err => {
    console.error(err);
    process.exit(1);
  });
}
