#!/usr/bin/env bash
# Restore script for Mobile Proxy Manager

set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARCHIVE="$1"

if [ -z "$ARCHIVE" ] || [ ! -f "$ARCHIVE" ]; then
  echo "Usage: ./restore.sh <path_to_backup_tar_gz>"
  exit 1
fi

FORCE="$2"

if [[ "$FORCE" != "-y" ]]; then
  read -p "Are you sure you want to restore from $ARCHIVE? Existing data will be overwritten! (y/N): " CONFIRM
  if [[ "$CONFIRM" != "y" && "$CONFIRM" != "Y" ]]; then
    echo "Restore cancelled."
    exit 0
  fi
fi

if command -v systemctl >/dev/null 2>&1 && systemctl is-active proxy-manager-backend.service >/dev/null 2>&1; then
  echo "Stopping backend service..."
  systemctl stop proxy-manager-backend.service
fi

echo "Restoring files..."
tar -xzf "$ARCHIVE" -C "$DIR"

if command -v systemctl >/dev/null 2>&1 && systemctl is-enabled proxy-manager-backend.service >/dev/null 2>&1; then
  echo "Restarting backend service..."
  systemctl restart proxy-manager-backend.service
fi

echo "Restore finished successfully."
