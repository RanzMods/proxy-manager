#!/usr/bin/env bash
# Backup script for Mobile Proxy Manager

set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="${DIR}/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
TARGET="${BACKUP_DIR}/backup_${TIMESTAMP}.tar.gz"

mkdir -p "$BACKUP_DIR"

echo "Creating backup: $TARGET ..."

tar -czf "$TARGET" \
  -C "$DIR" \
  database/ \
  .env \
  config/ 2>/dev/null || true

echo "Backup completed: $TARGET"
